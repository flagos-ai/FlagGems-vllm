"""Representative multi-wrap and tail case for external compute-sanitizer."""
import argparse,json,pathlib
import torch
import harness as H
from gate import single
p=argparse.ArgumentParser();p.add_argument('--stages',type=int,default=2);p.add_argument('--replays',type=int,default=100);a=p.parse_args()
B,C=H.load('baseline'),H.load('candidate');C.PIPE_STAGES=a.stages
base,cpu=H.case(257,16114,'correlated8',seed=901);base['max_query_len']=8192
base['k_scale']=torch.tensor([.75],device='cuda');base['v_scale']=torch.tensor([1.25],device='cuda')
check=single(B,C,base,cpu,native=False,literal=True);assert check['pass_'],check
out=torch.empty_like(base['q']);call=lambda:C.attn_auto(**base,output=out)
for _ in range(3):call()
torch.cuda.synchronize();g=torch.cuda.CUDAGraph()
with torch.cuda.graph(g):call()
first=out.clone()
for _ in range(a.replays):g.replay()
torch.cuda.synchronize();assert torch.equal(first,out)
print(json.dumps(dict(status='PASS_KERNEL_CHECKS_SANITIZER_STATUS_IS_EXTERNAL',check=check,stages=a.stages,replays=a.replays)),flush=True)
