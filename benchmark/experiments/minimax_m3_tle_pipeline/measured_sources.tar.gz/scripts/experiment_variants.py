"""Apply explicit experiment configuration to the imported candidate."""
def configure(C,args):
    C.PIPE_STAGES=args.stages
    C.PIPE_COMPACT_WARPS=getattr(args,'compact_warps',4)
    C.PIPE_PRODUCER_CONVERT=getattr(args,'producer_convert',False)
