"""Cheap domain, boundary, fallback and real-routing checks for the negative study."""
import json,pathlib,torch
import harness as H
from gate import single,identity
ROOT=pathlib.Path(__file__).resolve().parents[1]
B,C=H.load('baseline'),H.load('candidate')
C.PIPE_WARP_SPECIALIZE=False;C.PIPE_COMPACT_WARPS=8;C.PIPE_STAGES=2
report=dict(status='RUNNING',identity=identity(),configuration=dict(no_ws=True,compact_warps=8,stages=2),cases=[])
path=ROOT/'receipts/targeted-controls.json'
shapes=[(512,16384,'contig',128,1,1,'fp8'),(1024,16384,'contig',128,1,1,'fp8'),
        (2048,65536,'contig',128,1,1,'bf16'),(4096,32768,'correlated8',128,1,1,'fp8'),
        (6144,16384,'scattered',128,1,1,'fp8'),(257,16384,'scattered',96,1,1,'fp8'),
        (257,16384,'scattered',128,2,1,'fp8'),(257,16384,'contig',128,1,2,'fp8'),
        (257,131072,'scattered',128,1,1,'fp8')]
for q,seq,mode,d,hkv,batch,dtype in shapes:
    base,cpu=H.case(q,seq-q-13,mode,d=d,hkv=hkv,batch=batch,seq=seq,dtype=torch.bfloat16 if dtype=='bf16' else None)
    check=single(B,C,base,cpu,native=True,literal=True)
    row=dict(q=q,seq=seq,mode=mode,d=d,hkv=hkv,batch=batch,dtype=dtype,check=check)
    report['cases'].append(row);path.write_text(json.dumps(report,indent=2));print(json.dumps(row),flush=True)
for mode in ('duplicates','holes','all_invalid','unsorted'):
    base,cpu=H.case(513,15858,mode)
    check=single(B,C,base,cpu,native=mode=='duplicates',literal=True)
    row=dict(mode=mode,q=513,check=check);report['cases'].append(row);path.write_text(json.dumps(report,indent=2));print(json.dumps(row),flush=True)
for name in ('layer00-early.pt','layer00-late.pt','layer29-late.pt'):
    base,cpu=H.from_real_topk(name)
    check=single(B,C,base,cpu,native=False,literal=True)
    row=dict(real=name,Q_KV='synthetic; genuine TopK and routing metadata only',check=check)
    report['cases'].append(row);path.write_text(json.dumps(report,indent=2));print(json.dumps(row),flush=True)
report['status']='PASS' if all(x['check']['pass_'] for x in report['cases']) else 'FAIL';report['dispatch']=C._PIPE_DISPATCH
path.write_text(json.dumps(report,indent=2));print(report['status'],flush=True)
