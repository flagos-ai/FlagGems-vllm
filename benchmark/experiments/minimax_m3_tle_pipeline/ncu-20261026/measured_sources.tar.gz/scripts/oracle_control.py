"""Distinguish a frozen-baseline mismatch from independent FP32 accuracy."""

import json
from pathlib import Path

import torch

import harness as H
from profile_case import call_for, load85

ROOT = Path(__file__).resolve().parents[1]


def main():
    baseline, original = H.load("baseline"), load85()
    result = []
    for mode, storage in [
        (m, "fp8") for m in ("contig", "correlated8", "scattered")
    ] + [("contig", "bf16")]:
        base, cpu = H.case(8192, 8179, mode, seq=16384)
        if storage == "bf16":
            base["kv_cache"] = base["kv_cache"].to(torch.bfloat16)
        base["k_scale"] = torch.ones(1, device="cuda") if storage == "fp8" else None
        base["v_scale"] = torch.ones(1, device="cuda") if storage == "fp8" else None
        outputs = {name: torch.empty_like(base["q"]) for name in ("baseline", "fa85")}
        call_for(baseline, "baseline", base, outputs["baseline"])()
        call_for(original, "fa85", base, outputs["fa85"])()
        reference = H.literal_reference(base, cpu)
        torch.cuda.synchronize()
        row = {
            "mode": mode,
            "storage": storage,
            "baseline_vs_literal": H.diff(outputs["baseline"], reference),
            "fa85_vs_literal": H.diff(outputs["fa85"], reference),
        }
        result.append(row)
        print(json.dumps(row), flush=True)
    (ROOT / "receipts/oracle-control.json").write_text(
        json.dumps(result, indent=2) + "\n"
    )


if __name__ == "__main__":
    main()
