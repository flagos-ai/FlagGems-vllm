"""Uninstrumented paired full-attn_auto GPU and host timing with raw samples."""
import argparse,json,pathlib,statistics,time
import torch
import harness as H
from gate import identity,parity
ROOT=pathlib.Path(__file__).resolve().parents[1]

def stats(xs):
    x=sorted(xs)
    return dict(median=statistics.median(x),p10=x[int((len(x)-1)*.1)],p90=x[int((len(x)-1)*.9)],min=x[0],max=x[-1])

def capture(call):
    for _ in range(3):call()
    torch.cuda.synchronize();g=torch.cuda.CUDAGraph()
    with torch.cuda.graph(g):call()
    return g

def paired(calls,samples,rounds,warmup):
    assert samples>=100 and warmup>=30
    raw=[]
    for r in range(rounds):
        for i in range(warmup):
            for name in ('baseline','candidate') if i%2==0 else ('candidate','baseline'):calls[name]()
        torch.cuda.synchronize()
        events=[];round_wall=time.perf_counter_ns()
        for i in range(samples):
            for order,name in enumerate(('baseline','candidate') if (i+r)%2==0 else ('candidate','baseline')):
                start=torch.cuda.Event(enable_timing=True);end=torch.cuda.Event(enable_timing=True)
                start.record();t0=time.perf_counter_ns();calls[name]();t1=time.perf_counter_ns();end.record()
                events.append((r,i,order,name,start,end,(t1-t0)/1000))
        torch.cuda.synchronize();wall_us=(time.perf_counter_ns()-round_wall)/1000
        for r,i,order,name,start,end,host in events:
            raw.append(dict(round=r,sample=i,order=order,arm=name,gpu_us=start.elapsed_time(end)*1000,host_enqueue_us=host,paired_round_drained_wall_us=wall_us))
    summary={name:{metric:stats([row[metric] for row in raw if row['arm']==name]) for metric in ('gpu_us','host_enqueue_us')} for name in calls}
    round_ratios=[]
    for r in range(rounds):
        b=statistics.median([x['gpu_us'] for x in raw if x['round']==r and x['arm']=='baseline'])
        c=statistics.median([x['gpu_us'] for x in raw if x['round']==r and x['arm']=='candidate'])
        round_ratios.append(b/c)
    return dict(raw=raw,summary=summary,round_speedups=round_ratios,speedup=summary['baseline']['gpu_us']['median']/summary['candidate']['gpu_us']['median'])

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--q',nargs='+',type=int,default=[512,1024,2048,4096,6144,8192,8153]);ap.add_argument('--seq',nargs='+',type=int,default=[16384,32768,65536]);ap.add_argument('--modes',nargs='+',default=['contig','correlated8','scattered']);ap.add_argument('--samples',type=int,default=100);ap.add_argument('--rounds',type=int,default=3);ap.add_argument('--warmup',type=int,default=30);ap.add_argument('--no-ws',action='store_true');ap.add_argument('--producer-convert',action='store_true');ap.add_argument('--stages',type=int,default=2);ap.add_argument('--compact-warps',type=int,default=4);ap.add_argument('--compact-off',action='store_true');ap.add_argument('--wide-off',action='store_true');ap.add_argument('--real',action='store_true');ap.add_argument('--gate',default='correctness.json');ap.add_argument('--out',default='benchmark.json');args=ap.parse_args()
    gate=json.loads((ROOT/'receipts'/args.gate).read_text());assert gate['status']=='PASS','Correctness must pass before timing'
    B,C=H.load('baseline'),H.load('candidate');C.PIPE_STAGES=args.stages;C.PIPE_WARP_SPECIALIZE=not args.no_ws;C.PIPE_PRODUCER_CONVERT=args.producer_convert;C.PIPE_COMPACT_WARPS=args.compact_warps;C.PIPE_ENABLE_COMPACT=not args.compact_off;C.PIPE_ENABLE_WIDE=not args.wide_off
    report=dict(identity=identity(),configuration=vars(args),protocol=dict(samples=args.samples,rounds=args.rounds,warmup=args.warmup,stages=args.stages,complete_auto=True,host='Independent perf_counter enqueue and drained paired-round wall time. No CUDA-event subtraction.',compact=C.PIPE_ENABLE_COMPACT,wide=C.PIPE_ENABLE_WIDE),cases=[],status='RUNNING')
    dest=ROOT/'receipts'/args.out
    fixtures=[dict(q=q,seq=seq,mode=m) for q in args.q for seq in args.seq for m in args.modes]
    if args.real:fixtures=[dict(real=x) for x in ('layer00-early.pt','layer00-late.pt','layer29-late.pt')]
    for spec in fixtures:
        if 'real' in spec:base,cpu=H.from_real_topk(spec['real']);spec['Q_KV']='synthetic; real TopK and metadata only'
        else:base,cpu=H.case(spec['q'],spec['seq']-spec['q']-13,spec['mode'],seq=spec['seq'])
        outB,outC=torch.empty_like(base['q']),torch.empty_like(base['q'])
        calls={'baseline':lambda:B.attn_auto(**base,output=outB),'candidate':lambda:C.attn_auto(**base,output=outC)}
        calls['baseline']();calls['candidate']();torch.cuda.synchronize();check=parity(outC,outB)
        assert check['bitwise'],f'Bitwise failure in {spec}: {check}'
        graphs={name:capture(call) for name,call in calls.items()}
        row=dict(spec=spec,check=check)
        row['eager']=paired(calls,args.samples,args.rounds,args.warmup)
        row['graph']=paired({name:g.replay for name,g in graphs.items()},args.samples,args.rounds,args.warmup)
        report['cases'].append(row);report['dispatch']=C._PIPE_DISPATCH
        dest.write_text(json.dumps(report,indent=2));print(json.dumps(dict(spec=spec,eager_speedup=row['eager']['speedup'],graph_speedup=row['graph']['speedup'],eager_rounds=row['eager']['round_speedups'],graph_rounds=row['graph']['round_speedups'])),flush=True)
    report['status']='PASS_TIMING_COLLECTION';dest.write_text(json.dumps(report,indent=2))
if __name__=='__main__':main()
