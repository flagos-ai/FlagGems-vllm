"""Serial single-GPU collection; profiler and ordinary timings remain separate."""

import hashlib
import json
from pathlib import Path
import subprocess
import time

ROOT = Path(__file__).resolve().parents[1]


def main():
    jobs = []
    for arm in ["ws2", "nows2", "nows3", "fa85"]:
        for mode in ["contig", "correlated8", "scattered"]:
            jobs.append(("timing", arm, "fp8", mode))
    jobs.append(("timing", "fa85", "bf16", "contig"))
    for arm in ["baseline", "ws2", "nows2", "nows3", "fa85"]:
        for mode in ["contig", "correlated8", "scattered"]:
            jobs.append(("profile", arm, "fp8", mode))
    for arm in ["baseline", "fa85"]:
        jobs.append(("profile", arm, "bf16", "contig"))
    records = []
    for kind, arm, storage, mode in jobs:
        tag = f"{arm}-{storage}-{mode}"
        args = [
            "python3",
            "scripts/profile_case.py",
            "--arm",
            arm,
            "--storage",
            storage,
            "--mode",
            mode,
        ]
        if kind == "timing":
            args += ["--bench"]
            exists = ROOT / "receipts" / (tag + "-q8192-timing.json")
        else:
            exists = ROOT / "reports" / (tag + ".ncu-rep")
            args = [
                "/opt/ncu/ncu",
                "--set",
                "detailed",
                "--section",
                "SourceCounters",
                "--profile-from-start",
                "off",
                "--cache-control",
                "none",
                "--clock-control",
                "none",
                "-o",
                str(ROOT / "reports" / tag),
            ] + args
        if exists.exists():
            print("RETAIN_EXISTING", kind, tag, flush=True)
            continue
        log = ROOT / "analysis" / (kind + "-" + tag + ".log")
        start = time.monotonic()
        with log.open("w") as output:
            try:
                result = subprocess.run(
                    args,
                    cwd=ROOT,
                    stdout=output,
                    stderr=subprocess.STDOUT,
                    timeout=1200,
                )
                code = result.returncode
            except subprocess.TimeoutExpired:
                code = 124
        record = {
            "kind": kind,
            "tag": tag,
            "returncode": code,
            "elapsed_seconds": time.monotonic() - start,
            "command": args,
            "log_sha256": hashlib.sha256(log.read_bytes()).hexdigest(),
        }
        records.append(record)
        (ROOT / "analysis/campaign.json").write_text(
            json.dumps(records, indent=2) + "\n"
        )
        print(json.dumps(record), flush=True)
        if code:
            print(
                "ERROR_WINDOW",
                "\n".join(log.read_text().splitlines()[-12:]),
                flush=True,
            )
    subprocess.run(["python3", "scripts/analyze_ncu.py"], cwd=ROOT, check=True)


if __name__ == "__main__":
    main()
