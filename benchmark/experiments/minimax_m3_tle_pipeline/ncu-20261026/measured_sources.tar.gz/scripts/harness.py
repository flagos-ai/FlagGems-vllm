#!/usr/bin/env python3
"""Independent H100 refill attention checks; every timed arm is a full auto call.

No serving source is edited. Native vLLM and literal FP32 are references only.
TopK is token-major storage transposed to the production [Hkv,N,16] view.
"""
from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import math
import pathlib
import random
import statistics
import time

import torch

HERE = pathlib.Path(__file__).resolve().parents[1]
import sys
sys.path.insert(0,str(HERE / "src"))


def load(name):
    spec = importlib.util.spec_from_file_location(name, (HERE / "src" / "attention_candidate.py" if name == "candidate" else HERE / "reference" / (name + ".py")))
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def case(q_len, prefix, mode, *, d=128, hkv=1, batch=1, seed=123, dtype=None, seq=16384):
    assert prefix + q_len <= seq
    dtype = dtype or torch.float8_e4m3fn
    rng = torch.Generator().manual_seed(seed)
    pool, bs, topk = max(512, 2*math.ceil(seq/128)), 128, 16
    lens = [q_len - 37 * b for b in range(batch)]
    prefixes = [max(0, prefix - 17 * b) for b in range(batch)]
    cu = [0]
    for n in lens:
        cu.append(cu[-1] + n)
    total = cu[-1]
    q = torch.randn((total, 8 * hkv, d), generator=rng).to(torch.bfloat16).cuda()
    kv = torch.randn((pool, hkv, bs, 2 * d), generator=rng).to(torch.bfloat16).cuda().to(dtype)
    table = torch.stack([torch.randperm(pool, generator=rng)[:math.ceil(seq/128)+2] for _ in lens]).to(torch.int32)
    ids = torch.full((total, hkv, topk), -1, dtype=torch.int32)
    for b, n in enumerate(lens):
        for i in range(n):
            pos = prefixes[b] + i
            nb = pos // bs + 1
            for h in range(hkv):
                if mode == "all_invalid":
                    continue
                if mode == "contig":
                    row = torch.arange(max(0, nb - topk), nb)
                elif mode in ("correlated", "correlated8"):
                    group = 8 if mode=="correlated8" else 16
                    # Adjacent sixteen queries share the same scattered block set.
                    group_rng = torch.Generator().manual_seed(seed + b * 100000 + h * 10000 + i // group)
                    nb_group = (prefixes[b] + i // group * group) // bs + 1
                    row = torch.randperm(nb_group, generator=group_rng)[:topk].sort().values
                elif mode == "causal_padding":
                    nb_final = (prefixes[b] + n + bs - 1) // bs
                    row = torch.randperm(nb_final, generator=rng)[:topk].sort().values
                else:
                    row = torch.randperm(nb, generator=rng)[:topk].sort().values
                ids[cu[b] + i, h, :len(row)] = row
                if mode == "duplicates" and len(row) > 1:
                    ids[cu[b] + i, h, 1] = row[0]
                if mode in ("causal_padding", "holes"):
                    ids[cu[b] + i, h, 1::3] = -1
                if mode == "unsorted":
                    ids[cu[b]+i,h] = ids[cu[b]+i,h][torch.randperm(topk,generator=rng)]
    cpu = dict(lens=lens, prefixes=prefixes, cu=cu, table=table, ids=ids)
    base = dict(q=q, kv_cache=kv, topk_idx=ids.cuda().transpose(0, 1),
                block_table=table.cuda(), cu_seqlens_q=torch.tensor(cu, device="cuda", dtype=torch.int32),
                seq_lens=torch.tensor([p+n for p, n in zip(prefixes, lens)], device="cuda", dtype=torch.int32),
                prefix_lens=torch.tensor(prefixes, device="cuda", dtype=torch.int32),
                max_query_len=max(lens), num_kv_heads=hkv, sm_scale=d**-0.5)
    return base, cpu


def literal_reference(base, cpu):
    """Selected-list semantics: repeats carry multiplicity; -1 and future KV mask out."""
    q, kv = base["q"], base["kv_cache"]
    topk = base["topk_idx"].transpose(0, 1)
    bt = base["block_table"]
    ref = torch.empty_like(q, dtype=torch.float32)
    bs, d, hkv = 128, q.shape[-1], base["num_kv_heads"]
    key_offsets = torch.arange(bs, device="cuda")
    for b, n in enumerate(cpu["lens"]):
        for i in range(0, n, 16):
            begin, end = cpu["cu"][b]+i, cpu["cu"][b]+min(n, i+16)
            positions = cpu["prefixes"][b] + torch.arange(i, min(n, i+16), device="cuda")
            for h in range(hkv):
                ids = topk[begin:end, h].long()
                pages = bt[b, ids.clamp_min(0)].long()
                data = kv[pages, h].float()
                keys = data[..., :d].reshape(end-begin, -1, d)
                values = data[..., d:].reshape(end-begin, -1, d)
                pos = (ids[:, :, None]*bs + key_offsets).reshape(end-begin, -1)
                valid = ((ids[:, :, None] >= 0).expand(-1,-1,bs).reshape(end-begin,-1)
                         & (pos <= positions[:, None]) & (pos < base["seq_lens"][b]))
                logits = torch.einsum("qhd,qkd->qhk", q[begin:end,h*8:(h+1)*8].float(), keys) * base["sm_scale"]
                if base.get("k_scale") is not None:
                    logits=logits*base["k_scale"]
                logits = logits.masked_fill(~valid[:,None,:], -float("inf"))
                maxima = logits.amax(-1, keepdim=True)
                maxima = torch.where(torch.isfinite(maxima), maxima, 0)
                weights = torch.exp(logits-maxima)
                weights = weights / weights.sum(-1,keepdim=True).clamp_min(1e-30)
                result=torch.einsum("qhk,qkd->qhd", weights, values)
                if base.get("v_scale") is not None:
                    result=result*base["v_scale"]
                ref[begin:end,h*8:(h+1)*8] = result
    return ref


def diff(got, ref, *, atol=.004, rtol=.04):
    delta = (got.float()-ref.float()).abs()
    bound = atol + rtol*ref.float().abs()
    return dict(pass_=bool(torch.isfinite(got).all() and (delta <= bound).all()),
                max_abs=float(delta.max()), rms=float(delta.square().mean().sqrt()),
                failures=int((delta>bound).sum()), atol=atol, rtol=rtol)


def checked(fn, base, ref):
    q = base["q"]
    storage = torch.full((q.shape[0]+2,*q.shape[1:]), 313, device="cuda", dtype=q.dtype)
    out = storage[1:-1]
    out.fill_(float("nan"))
    fn(out)
    torch.cuda.synchronize()
    first = out.clone()
    cov = bool(torch.isfinite(out).all() and (storage[0]==313).all() and (storage[-1]==313).all())
    out.fill_(-777)
    fn(out)
    torch.cuda.synchronize()
    cov = cov and bool(torch.equal(first,out)) and bool((storage[0]==313).all() and (storage[-1]==313).all())
    result = diff(out,ref)
    result.update(exact_write_coverage=cov, deterministic=bool(torch.equal(first,out)))
    result["pass_"] = result["pass_"] and cov
    return out, result


def graph(fn):
    for _ in range(3):
        fn()
    torch.cuda.synchronize()
    g = torch.cuda.CUDAGraph()
    with torch.cuda.graph(g):
        fn()
    return g


def timed(fn, iters):
    torch.cuda.synchronize()
    start, end = torch.cuda.Event(enable_timing=True), torch.cuda.Event(enable_timing=True)
    start.record()
    for _ in range(iters):
        fn()
    end.record()
    end.synchronize()
    return start.elapsed_time(end)*1000/iters


def gate_stats(base, cpu, bq, maxspan):
    result = dict(compact=0, wide=0, scattered=0, duplicates=0, empty=0, total=0)
    for b,n in enumerate(cpu["lens"]):
        for h in range(base["num_kv_heads"]):
            for i in range(0,n,bq):
                x=cpu["ids"][cpu["cu"][b]+i:cpu["cu"][b]+min(n,i+bq),h]
                valid=x[x>=0]
                result["total"]+=1
                if not valid.numel():
                    result["empty"]+=1; result["compact"]+=1; continue
                span=int(valid.max()-valid.min())+1
                if span > maxspan or span*x.shape[0] > max(1,maxspan//16)*len(valid):
                    result["scattered"]+=1; continue
                dup=any(len(z[z>=0])!=len(z[z>=0].unique()) for z in x)
                if dup:
                    result["duplicates"]+=1
                else:
                    result["compact"]+=1
                    if span>64: result["wide"]+=1
    return result


def resources(module):
    result=[]
    for name in ("_union_span_kernel","_split_kernel","_span_split_kernel","_merge_split_kernel","_wide_union_sparse_kernel"):
        if not hasattr(module,name):
            continue
        jit=getattr(module,name)
        for device,cache in getattr(jit,"device_caches",{}).items():
            try:
                binaries=cache[0]
                for kernel in binaries.values():
                    meta=kernel.metadata
                    result.append(dict(kernel=name,device=device,n_regs=getattr(kernel,"n_regs",None),n_spills=getattr(kernel,"n_spills",None),
                                       shared=getattr(meta,"shared",None),num_warps=getattr(meta,"num_warps",None),num_stages=getattr(meta,"num_stages",None)))
            except Exception as e:
                result.append(dict(kernel=name,inspection_error=str(e)))
    return result



def from_real_topk(name,seed=888):
    """Genuine routing metadata with fresh synthetic Q/KV, explicitly labeled."""
    x=torch.load(HERE/'reference'/name,map_location='cpu',weights_only=False)
    rng=torch.Generator().manual_seed(seed)
    q=torch.randn(x['q_shape'],generator=rng).to(torch.bfloat16).cuda()
    kv=torch.randn(x['kv_shape'],generator=rng,dtype=torch.bfloat16).cuda().to(torch.float8_e4m3fn)
    base=dict(q=q,kv_cache=kv,topk_idx=x['topk'].transpose(0,1).contiguous().cuda().transpose(0,1),
        block_table=x['block_table'].cuda(),cu_seqlens_q=x['cu_seqlens_q'].cuda(),seq_lens=x['seq_lens'].cuda(),
        prefix_lens=x['prefix_lens'].cuda(),max_query_len=x['max_query_len'],num_kv_heads=x['num_kv_heads'],sm_scale=x['sm_scale'])
    cpu=dict(lens=x['cu_seqlens_q'].diff().tolist(),prefixes=x['prefix_lens'].tolist(),cu=x['cu_seqlens_q'].tolist(),table=x['block_table'],ids=x['topk'].transpose(0,1))
    return base,cpu
