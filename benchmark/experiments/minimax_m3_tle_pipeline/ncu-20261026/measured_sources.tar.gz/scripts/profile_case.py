"""Isolated NCU range and uninstrumented paired timing on identical inputs."""

import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import types

import torch
import triton

import harness as H
from bench import capture, paired
from gate import parity

ROOT = Path(__file__).resolve().parents[1]


def load85():
    # Only the platform-query import is supplied; all original kernels/launches
    # remain byte-identical to PR #85. PDL is unused by prefill.
    package = types.ModuleType("flag_attn")
    package.__path__ = []
    utils = types.ModuleType("flag_attn.utils")
    utils.current_platform = types.SimpleNamespace(is_arch_support_pdl=lambda: False)
    sys.modules.setdefault("flag_attn", package)
    sys.modules.setdefault("flag_attn.utils", utils)
    spec = importlib.util.spec_from_file_location(
        "fa85", ROOT / "reference/flagattention_pr85.py"
    )
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def module_for(arm):
    if arm == "baseline":
        return H.load("baseline")
    if arm == "fa85":
        return load85()
    module = H.load("candidate")
    module.PIPE_STAGES = 3 if arm == "nows3" else 2
    module.PIPE_WARP_SPECIALIZE = arm == "ws2"
    module.PIPE_COMPACT_WARPS = 4 if arm == "ws2" else 8
    return module


def call_for(module, arm, base, output):
    fn = module.minimax_m3_sparse_attn if arm == "fa85" else module.attn_auto
    return lambda: fn(**base, output=output)


def fixture(args):
    base, _ = H.case(args.q, args.seq - args.q - 13, args.mode, seq=args.seq)
    if args.storage == "bf16":
        # Preserve values from the FP8 fixture; only storage width changes.
        base["kv_cache"] = base["kv_cache"].to(torch.bfloat16)
    base["k_scale"] = torch.ones(1, device="cuda") if args.storage == "fp8" else None
    base["v_scale"] = torch.ones(1, device="cuda") if args.storage == "fp8" else None
    return base


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument(
        "--arm",
        choices=["baseline", "ws2", "nows2", "nows3", "fa85"],
        default="baseline",
    )
    ap.add_argument(
        "--mode", choices=["contig", "correlated8", "scattered"], default="contig"
    )
    ap.add_argument("--q", type=int, default=8192)
    ap.add_argument("--seq", type=int, default=16384)
    ap.add_argument("--storage", choices=["fp8", "bf16"], default="fp8")
    ap.add_argument("--bench", action="store_true")
    args = ap.parse_args()
    assert torch.cuda.device_count() == 1
    assert torch.cuda.get_device_capability() == (9, 0)
    base = fixture(args)
    baseline = H.load("baseline")
    candidate = module_for(args.arm)
    expected, output = torch.empty_like(base["q"]), torch.empty_like(base["q"])
    calls = {
        "baseline": call_for(baseline, "baseline", base, expected),
        "candidate": call_for(candidate, args.arm, base, output),
    }
    for call in calls.values():
        call()
    torch.cuda.synchronize()
    check = parity(output, expected)
    check["tolerance_vs_frozen_baseline"] = H.diff(output, expected)
    strict = args.arm != "fa85"
    accepted = (
        check["bitwise"] if strict else check["tolerance_vs_frozen_baseline"]["pass_"]
    )
    report = {
        "configuration": vars(args),
        "identity": {
            "torch": torch.__version__,
            "triton": triton.__version__,
            "gpu": torch.cuda.get_device_name(),
            "sources": {
                str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest()
                for sub in ("src", "reference", "scripts")
                for p in (ROOT / sub).glob("*.py")
            },
        },
        "check": check,
        "accepted": accepted,
        "math": "fa85 uses FP8 QK when storage=fp8; other arms use BF16 QK/PV",
    }
    tag = f"{args.arm}-{args.storage}-{args.mode}-q{args.q}"
    dest = (
        ROOT
        / "receipts"
        / (tag + ("-timing.json" if args.bench else "-profile-gate.json"))
    )
    if not accepted:
        report["status"] = "NUMERICAL_REJECTION"
        dest.write_text(json.dumps(report, indent=2) + "\n")
        print(
            json.dumps({"tag": tag, "status": report["status"], "check": check}),
            flush=True,
        )
        raise SystemExit(2)
    if args.bench:
        graphs = {name: capture(call) for name, call in calls.items()}
        report["eager"] = paired(calls, 100, 3, 30)
        report["graph"] = paired(
            {name: graph.replay for name, graph in graphs.items()}, 100, 3, 30
        )
        report["status"] = "PASS_UNINSTRUMENTED_TIMING"
        print(
            json.dumps(
                {
                    "tag": tag,
                    "check": check,
                    "eager_ratio": report["eager"]["speedup"],
                    "graph_ratio": report["graph"]["speedup"],
                }
            ),
            flush=True,
        )
    else:
        for _ in range(30):
            calls["candidate"]()
        torch.cuda.synchronize()
        torch.cuda.cudart().cudaProfilerStart()
        calls["candidate"]()
        torch.cuda.synchronize()
        torch.cuda.cudart().cudaProfilerStop()
        report["status"] = "PASS_SINGLE_PROFILE_RANGE"
        print(
            json.dumps({"tag": tag, "status": report["status"], "check": check}),
            flush=True,
        )
    dest.write_text(json.dumps(report, indent=2) + "\n")


if __name__ == "__main__":
    main()
