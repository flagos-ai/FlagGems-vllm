"""Strict baseline parity plus unchanged literal/native checks and graph mutation."""
import argparse, hashlib, json, pathlib, sys, time, traceback
import torch
import harness as H
ROOT=pathlib.Path(__file__).resolve().parents[1]

def parity(got,ref):
    delta=(got.float()-ref.float()).abs()
    return dict(bitwise=bool(torch.equal(got,ref)),max_abs=float(delta.max()),rms=float(delta.square().mean().sqrt()),different_elements=int((got!=ref).sum()),finite=bool(torch.isfinite(got).all()))

def identity():
    import triton
    return dict(torch=torch.__version__,cuda=torch.version.cuda,triton=triton.__version__,triton_file=triton.__file__,gpu=torch.cuda.get_device_name(),capability=torch.cuda.get_device_capability(),sources={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for sub in ('src','reference','scripts') for p in (ROOT/sub).glob('*.py')})

def single(B,C,base,cpu,*,native=True,literal=True):
    guard=torch.full((base['q'].shape[0]+2,*base['q'].shape[1:]),313,device='cuda',dtype=torch.bfloat16)
    out=guard[1:-1];out.fill_(float('nan'))
    expected=torch.empty_like(out);B.attn_auto(**base,output=expected)
    C.attn_auto(**base,output=out);torch.cuda.synchronize()
    check=parity(out,expected)
    check['redzone']=bool((guard[0]==313).all() and (guard[-1]==313).all())
    first=out.clone()
    for _ in range(10):C.attn_auto(**base,output=out)
    torch.cuda.synchronize();check['deterministic_10']=bool(torch.equal(first,out))
    if literal:
        ref=H.literal_reference(base,cpu)
        check['literal_candidate']=H.diff(out,ref);check['literal_baseline']=H.diff(expected,ref)
    if native:
        native_module=H.load('native_sparse_attn')
        ref=torch.empty_like(out);native_module.minimax_m3_sparse_attn(**base,output=ref)
        torch.cuda.synchronize();check['native']=H.diff(out,ref)
    check['pass_']=(check['bitwise'] and check['redzone'] and check['deterministic_10'] and check['finite']
          and (not literal or (check['literal_candidate']['pass_'] and check['literal_baseline']['pass_']))
          and (not native or check['native']['pass_']))
    return check

def mutate(dst,src):
    count=src['q'].shape[0]
    dst['q'][:count].copy_(src['q']);dst['kv_cache'].copy_(src['kv_cache'])
    dst['topk_idx'][:,:count].copy_(src['topk_idx'])
    for key in ('block_table','cu_seqlens_q','seq_lens','prefix_lens','k_scale','v_scale'):dst[key].copy_(src[key])
    return count

def graphs(B,C,q=8153,seq=32768,stress=1000):
    fixed,_=H.case(q,seq-q-13,'contig',seq=seq,seed=730)
    fixed['k_scale']=torch.tensor([.75],device='cuda');fixed['v_scale']=torch.tensor([1.25],device='cuda')
    # Two graphs on two streams get distinct flag/workspace allocations.
    streams=[torch.cuda.Stream(),torch.cuda.Stream()];graphs=[];guards=[]
    for stream in streams:
        guard=torch.full((q+2,8,128),313,device='cuda',dtype=torch.bfloat16);out=guard[1:-1]
        with torch.cuda.stream(stream):
            for _ in range(3):C.attn_auto(**fixed,output=out)
        stream.synchronize();g=torch.cuda.CUDAGraph()
        with torch.cuda.graph(g,stream=stream):C.attn_auto(**fixed,output=out)
        graphs.append(g);guards.append(guard)
    A,_=H.case(q,seq-q-13,'correlated8',seq=seq,seed=731)
    A['k_scale']=torch.tensor([.625],device='cuda');A['v_scale']=torch.tensor([1.375],device='cuda')
    Bstate,_=H.case(q-7,17,'holes',seq=seq,seed=732)
    Bstate['k_scale']=torch.tensor([1.125],device='cuda');Bstate['v_scale']=torch.tensor([.875],device='cuda')
    empty,_=H.case(q-13,0,'all_invalid',seq=seq,seed=733)
    empty['k_scale']=torch.tensor([1.5],device='cuda');empty['v_scale']=torch.tensor([.5],device='cuda')
    phases=[];savedA=None
    for name,state in [('A',A),('B',Bstate),('A_restore',A),('empty',empty),('A_restore2',A)]:
        count=mutate(fixed,state);torch.cuda.synchronize()
        expected=torch.full_like(fixed['q'],733);B.attn_auto(**fixed,output=expected);torch.cuda.synchronize()
        for guard in guards:guard[1:-1].fill_(733);guard[1:count+1].fill_(float('nan'))
        for stream,g in zip(streams,graphs):
            with torch.cuda.stream(stream):g.replay()
        torch.cuda.synchronize();checks=[]
        for guard in guards:
            out=guard[1:-1];check=parity(out[:count],expected[:count])
            check['redzone']=bool((guard[0]==313).all() and (guard[-1]==313).all() and (out[count:]==733).all())
            checks.append(check)
        if name=='A':savedA=guards[0][1:count+1].clone()
        phases.append(dict(phase=name,active_tokens=count,checks=checks,restored_bitwise=True if not name.startswith('A_restore') else bool(torch.equal(savedA,guards[0][1:count+1]))))
    first=[guard.clone() for guard in guards]
    for _ in range(stress):
        for stream,g in zip(streams,graphs):
            with torch.cuda.stream(stream):g.replay()
    torch.cuda.synchronize()
    unchanged=all(torch.equal(x,y) for x,y in zip(first,guards))
    flags=list(C._AUTO_FLAGS.items());flags2=list(C._AUTO_WIDE_FLAGS.items())
    independent=len({t.data_ptr() for _,t in flags})==len(flags) and len({t.data_ptr() for _,t in flags2})==len(flags2)
    passed=all(c['bitwise'] and c['finite'] and c['redzone'] for p in phases for c in p['checks']) and all(p['restored_bitwise'] for p in phases) and unchanged and independent
    return dict(pass_=passed,phases=phases,stress_replays_per_graph=stress,stress_unchanged=unchanged,distinct_flag_workspaces=independent,streams=[s.cuda_stream for s in streams])

def real_case(name):
    # Routing dump contains genuine TopK/lengths, not genuine Q or KV values.
    data=torch.load(ROOT/'reference'/name,map_location='cpu',weights_only=False)
    return data

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--stages',type=int,default=2);ap.add_argument('--quick',action='store_true');ap.add_argument('--graphs-only',action='store_true');ap.add_argument('--no-graphs',action='store_true');ap.add_argument('--out',default='correctness.json');args=ap.parse_args()
    B,C=H.load('baseline'),H.load('candidate');C.PIPE_STAGES=args.stages
    assert torch.cuda.device_count()==1 and torch.cuda.get_device_capability()==(9,0)
    report=dict(identity=identity(),stages=args.stages,cases=[],graph={},status='RUNNING')
    dest=ROOT/'receipts'/args.out
    def save():dest.write_text(json.dumps(report,indent=2))
    shapes=[]
    if not args.graphs_only:
        if args.quick:shapes=[(8192,16384,'contig',128,1,1,'fp8'),(8192,16384,'correlated8',128,1,1,'fp8'),(8153,16384,'scattered',128,1,1,'fp8')]
        else:
            shapes=[(q,seq,mode,128,1,1,'fp8') for q in (512,1024,2048,4096,6144,8192,8153) for seq in (16384,32768,65536) for mode in ('contig','correlated8','scattered')]
            shapes += [(8153,16384,m,128,1,1,'fp8') for m in ('duplicates','holes','all_invalid','unsorted','causal_padding')]
            shapes += [(8153,16384,'contig',128,1,1,'bf16'),(8153,16384,'correlated8',128,1,1,'bf16'),(1001,16384,'scattered',96,1,1,'fp8'),(1001,16384,'scattered',128,2,1,'fp8'),(1024,16384,'correlated8',128,1,2,'fp8'),(8153,131072,'scattered',128,1,1,'fp8')]
    try:
        for q,seq,mode,d,hkv,batch,dtype in shapes:
            base,cpu=H.case(q,seq-q-13,mode,d=d,hkv=hkv,batch=batch,seq=seq,dtype=torch.bfloat16 if dtype=='bf16' else None)
            base['k_scale']=torch.tensor([.75],device='cuda') if dtype=='fp8' else None
            base['v_scale']=torch.tensor([1.25],device='cuda') if dtype=='fp8' else None
            row=dict(q=q,seq=seq,mode=mode,d=d,hkv=hkv,batch=batch,dtype=dtype)
            row['check']=single(B,C,base,cpu,native=mode not in ('holes','all_invalid','causal_padding','unsorted'),literal=True)
            report['cases'].append(row);save();print(json.dumps(row),flush=True)
            if not row['check']['pass_']:raise RuntimeError('Strict eager correctness gate failed')
        if not args.quick and not args.graphs_only:
            for name in ('layer00-early.pt','layer00-late.pt','layer29-late.pt'):
                base,cpu=H.from_real_topk(name)
                check=single(B,C,base,cpu,native=False,literal=True)
                report['cases'].append(dict(real=name,Q_KV='synthetic; real TopK and metadata only',check=check));save()
                print(json.dumps(dict(real=name,check=check)),flush=True)
                if not check['pass_']:raise RuntimeError('Real TopK gate failed')
            for kind in ('kv_stride','topk_bt_stride'):
                base,cpu=H.case(8153,8154,'correlated8')
                if kind=='kv_stride':
                    x=torch.empty((*base['kv_cache'].shape[:-1],272),device='cuda',dtype=base['kv_cache'].dtype);x[...,:256].copy_(base['kv_cache']);base['kv_cache']=x[...,:256]
                else:
                    x=torch.empty((*base['topk_idx'].shape[:-1],32),device='cuda',dtype=torch.int32);x[...,::2].copy_(base['topk_idx']);base['topk_idx']=x[...,::2]
                    t=torch.empty((1,2*base['block_table'].shape[1]),device='cuda',dtype=torch.int32);t[:,::2].copy_(base['block_table']);base['block_table']=t[:,::2]
                check=single(B,C,base,cpu,native=False,literal=True);report['cases'].append(dict(control=kind,check=check));save()
                if not check['pass_']:raise RuntimeError('Stride control gate failed')
        if not args.no_graphs:
            report['graph']=[graphs(B,C,q=8153,seq=seq,stress=100 if args.quick else 1000) for seq in (16384,32768)];save();print(json.dumps(report['graph']),flush=True)
            if not all(x['pass_'] for x in report['graph']):raise RuntimeError('Graph gate failed')
        report['status']='PASS'
    except BaseException as error:
        report.update(status='FAIL',error=str(error),traceback=traceback.format_exc());save();raise
    finally:report['dispatch']=C._PIPE_DISPATCH;save()
if __name__=='__main__':main()
