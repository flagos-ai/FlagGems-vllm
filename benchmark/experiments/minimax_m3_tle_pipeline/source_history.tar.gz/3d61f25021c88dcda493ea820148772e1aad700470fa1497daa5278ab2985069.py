"""Compile SM90 without initializing CUDA; retain all generated artifacts."""
import argparse, hashlib, json, pathlib, re, sys, traceback
ROOT=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
import triton
from triton.backends.compiler import GPUTarget
from triton.compiler import ASTSource
from tle_pipeline import _union_tle_kernel

def main():
    a=argparse.ArgumentParser();a.add_argument('--stages',type=int,default=2);a.add_argument('--bq',type=int,default=8);a.add_argument('--sparse',action='store_true');a.add_argument('--bf16',action='store_true');args=a.parse_args()
    kind=f'{"wide" if args.sparse else "compact"}-q{args.bq}-s{args.stages}-{ "bf16" if args.bf16 else "fp8"}'
    out=ROOT/'artifacts'/kind;out.mkdir(parents=True,exist_ok=True)
    dtype='bf16' if args.bf16 else 'fp8e4nv'
    sig={n:'i32' for n in _union_tle_kernel.arg_names}
    for n in ('q_ptr','o_ptr'):sig[n]='*bf16'
    sig['kv_ptr']='*'+dtype;sig['kv_desc']=f'tensordesc<{dtype}[128,128]>'
    for n in ('t_ptr','bt_ptr','cu_ptr','seq_ptr','pre_ptr','auto_flags_ptr','parent_flags_ptr'):sig[n]='*i32'
    for n in ('k_scale_ptr','v_scale_ptr'):sig[n]='*fp32'
    sig['sm_scale']='fp32'
    const=dict(gqa_group_size=8,head_dim=128,max_topk=16,heads_total=8,stride_qn=128,
        stride_kv_blk=32768,stride_kv_h=32768,stride_kv_pos=256,stride_kv_d=1,
        stride_th=8192*16,stride_tn=16,stride_tk=1,stride_bt_b=514,
        BLOCK_Q=args.bq,BLOCK_K=128,BLOCK_D=128,TOPK=16,QH=8,SPAN=32,HAS_SCALE=True,
        D_POW2=True,INT8_QK=False,AUTO_SPAN=128 if args.sparse else 64,stride_bt_k=1,
        SPARSE_WALK=args.sparse,PARENT_BLOCK_Q=16 if args.sparse else 0,PARENT_TILES=512 if args.sparse else 0,
        PIPE_STAGES=args.stages,WARP_SPECIALIZE=True)
    rec=dict(status='STARTED',mode='CPU_OFFLINE_ONLY',gpu_execution=False,args=vars(args),triton_path=triton.__file__,source_sha256=hashlib.sha256((ROOT/'src/tle_pipeline.py').read_bytes()).hexdigest())
    try:
        compiled=triton.compile(ASTSource(_union_tle_kernel,sig,constexprs=const),target=GPUTarget('cuda',90,32),options={'num_warps':4,'num_stages':1})
        for key,value in compiled.asm.items():
            (out/f'kernel.{key}').write_bytes(value if isinstance(value,bytes) else value.encode())
        ptx=compiled.asm['ptx'];meta=compiled.metadata
        rec.update(status='PASS_OFFLINE_COMPILE',metadata=meta._asdict(),ptx_counts={k:len(re.findall(v,ptx)) for k,v in dict(tma=r'cp\.async\.bulk\.tensor',wgmma_bf16=r'wgmma\.mma_async[^\n]*bf16\.bf16',wgmma_fp8=r'wgmma\.mma_async[^\n]*e4m3',barrier=r'mbarrier\.',wgmma_wait=r'wgmma\.wait_group',ws_barriers=r'bar\.sync').items()})
    except BaseException as e:
        rec.update(status='FAIL_OFFLINE_COMPILE',error=str(e),traceback=traceback.format_exc())
    (out/'receipt.json').write_text(json.dumps(rec,indent=2,default=str));print(json.dumps(rec,indent=2,default=str))
    if rec['status'].startswith('FAIL'):sys.exit(1)
if __name__=='__main__':main()
