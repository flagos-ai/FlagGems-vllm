import importlib.util,json,sys,unittest
from pathlib import Path
sys.path.insert(0,'/source/tools')
def load(name,path):
 spec=importlib.util.spec_from_file_location(name,path)
 module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module
module=load('ci_helper_negative','/source/tools/test_ci_helpers.py')
module.select_tests=load('main_selector_negative','/baseline-selector.py')
case=module.SelectTestsTest('test_nvidia_tuning_changes_select_all_functional_tests')
result=unittest.TextTestRunner(verbosity=2).run(unittest.TestSuite([case]))
matched=result.testsRun==1 and len(result.failures)==2 and not result.errors and all('Lists differ' in text for _,text in result.failures)
Path('/results/baseline-selector-negative.json').write_text(json.dumps({'baseline':'12210ab628e0b8f5beed55791958e3bd57accb2b','matched_expected_failure':matched,'tests':result.testsRun,'failures':len(result.failures),'errors':len(result.errors)},indent=2)+'\n')
raise SystemExit(not matched)
