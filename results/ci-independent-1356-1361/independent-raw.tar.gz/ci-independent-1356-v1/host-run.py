import hashlib
import json
import subprocess
import time
from pathlib import Path

ROOT = Path('/data/codex/fgv-revalidation-20261127/ci-independent-1356-v1')
IMAGE = 'sha256:bd8a5d7a8774800c92d714c0c226b32c1863f929150f36efd610aebcd12a335d'
LABEL = 'fgv-ci-independent-1356-v1'
def cmd(argv):
    return subprocess.run(argv, capture_output=True, text=True, check=True)
def inspect(cid):
    return json.loads(cmd(['docker', 'inspect', cid]).stdout)[0]
assert ROOT.is_dir() and not ROOT.is_symlink()
assert cmd(['docker', 'image', 'inspect', '--format', '{{.Id}}', IMAGE]).stdout.strip() == IMAGE
manifest = json.loads((ROOT / 'manifest.json').read_text())
for path, expected in manifest.items():
    assert hashlib.sha256((ROOT / path).read_bytes()).hexdigest() == expected, path
results = ROOT / 'results'
results.mkdir()
argv = ['docker', 'create', '--name', LABEL, '--label', 'codex.task=' + LABEL, '--runtime=runc', '--network=none', '--cap-drop=ALL', '--read-only', '--pids-limit=256', '--cpus=2', '--memory=4g', '--tmpfs=/tmp:rw,exec,nosuid,nodev,size=768m', '--security-opt=no-new-privileges', '--env', 'NVIDIA_VISIBLE_DEVICES=void', '--env', 'CUDA_VISIBLE_DEVICES=', '--env', 'VLLM_PLUGINS=', '--env', 'PYTHONDONTWRITEBYTECODE=1', '--env', 'PYTEST_DISABLE_PLUGIN_AUTOLOAD=1', '--env', 'PYTHONUTF8=1', '--workdir=/source', '--entrypoint=/usr/bin/python3']
for host, guest, mode in [('source','source','ro'), ('source-manifest.json','source-manifest.json','ro'), ('verify-source.py','verify-source.py','ro'), ('baseline-selector.py','baseline-selector.py','ro'), ('wheels','wheels','ro'), ('run-cpu.py','run-cpu.py','ro'), ('negative-control.py','negative-control.py','ro'), ('baseline-conftest.py','baseline-conftest.py','ro'), ('results','results','rw')]:
    argv += ['--mount', f'type=bind,src={ROOT / host},dst=/{guest}' + (',readonly' if mode == 'ro' else '')]
argv += [IMAGE, '-B', '/run-cpu.py']
cid = cmd(argv).stdout.strip()
(ROOT / 'cid').write_text(cid + '\n')
before = inspect(cid)
assert before['Config']['Labels']['codex.task'] == LABEL and before['Image'] == IMAGE
hc = before['HostConfig']
assert hc['Runtime'] == 'runc' and hc['NetworkMode'] == 'none' and hc['ReadonlyRootfs'] and hc['CapDrop'] == ['ALL']
assert not hc.get('Devices') and not hc.get('DeviceRequests') and not hc.get('Privileged')
(ROOT / 'admission.json').write_text(json.dumps({'cid': cid, 'label': LABEL, 'image': before['Image'], 'runtime': hc['Runtime'], 'network': hc['NetworkMode'], 'readonly_root': hc['ReadonlyRootfs'], 'cap_drop': hc['CapDrop'], 'devices': hc['Devices'], 'device_requests': hc['DeviceRequests'], 'privileged': hc['Privileged'], 'mounts': [{'target':m['Destination'],'rw':m['RW']} for m in before['Mounts']]}, indent=2) + '\n')
cmd(['docker', 'start', cid])
deadline = time.monotonic() + 600
timed_out = False
while True:
    current = inspect(cid)
    assert current['Config']['Labels']['codex.task'] == LABEL and current['Id'] == cid
    if not current['State']['Running']:
        break
    if time.monotonic() > deadline:
        timed_out = True
        cmd(['docker', 'stop', '--time', '10', cid])
        current = inspect(cid)
        break
    time.sleep(2)
log_result = cmd(['docker', 'logs', cid])
(ROOT / 'container.log').write_text(log_result.stdout + log_result.stderr)
(ROOT / 'final-state.json').write_text(json.dumps({'cid':cid,'state':current['State'],'timed_out':timed_out},indent=2) + '\n')
cmd(['docker', 'rm', cid])
remaining = cmd(['docker', 'ps', '-a', '--no-trunc', '--format', '{{.ID}}']).stdout.splitlines()
assert cid not in remaining
(ROOT / 'cleanup.json').write_text(json.dumps({'cid':cid,'positive_absence':True,'natural_exit':not timed_out,'exit':current['State']['ExitCode']},indent=2) + '\n')
(ROOT / 'host.exit').write_text(str(int(timed_out or current['State']['ExitCode'] != 0)) + '\n')
