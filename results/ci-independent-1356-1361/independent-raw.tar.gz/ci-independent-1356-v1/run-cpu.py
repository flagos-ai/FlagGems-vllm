import hashlib
import importlib.metadata
import json
import os
import subprocess
import sys
from pathlib import Path

out = Path('/results')
os.chdir('/source')
os.environ['PYTHONPATH'] = '/tmp/ci-lint'
files = ['tools/test_ci_helpers.py', 'tools/select_tests.py']
phases = [
    ('lint-dependencies', [sys.executable, '-m', 'pip', 'install', '--no-index', '--no-deps', '--target', '/tmp/ci-lint', *map(str, sorted(Path('/wheels').glob('*.whl')))]),
    ('all-ci-helpers', [sys.executable, '-m', 'unittest', 'discover', '-s', 'tools', '-p', 'test_ci_*.py', '-v']),
    ('workflow-policy', [sys.executable, 'tools/ci_checks/check_workflow_policy.py']),
    ('workflow-policy-tests', [sys.executable, '-m', 'unittest', 'discover', '-s', 'tools/ci_checks', '-p', 'test_check_workflow_policy.py', '-v']),
    ('no-torch-fallback', [sys.executable, 'tools/ci_checks/check_no_torch_fallback.py', *files]),
    ('init-exports', [sys.executable, 'tools/ci_checks/check_init_exports.py']),
    ('export-registry', [sys.executable, 'tools/ci_checks/check_exported_ops_registered.py']),
    ('black', [sys.executable, '-m', 'black', '--check', '--diff', *files]),
    ('isort', [sys.executable, '-m', 'isort', '--check-only', '--diff', '--profile', 'black', *files]),
    ('flake8', [sys.executable, '-m', 'flake8', '--ignore=F405,E731,W503,E203,E704', '--max-line-length=120', *files]),
    ('baseline-selector-negative', [sys.executable, '/negative-control.py']),
]
subprocess.run([sys.executable, '/verify-source.py', '/source', '/source-manifest.json'], stdout=(out/'source-before.json').open('w'), check=True)
results = []
for name, argv in phases:
    result = subprocess.run(argv, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=180)
    data = result.stdout
    (out / f'{name}.log').write_bytes(data)
    row = {'phase': name, 'argv': argv, 'exit': result.returncode, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
    results.append(row)
    (out / 'phases.json').write_text(json.dumps(results, indent=2) + '\n')
    print(json.dumps(row), flush=True)
    if name == 'lint-dependencies' and result.returncode:
        break
subprocess.run([sys.executable, '/verify-source.py', '/source', '/source-manifest.json'], stdout=(out/'source-after.json').open('w'), check=True)
versions = {name: importlib.metadata.version(name) for name in ['pytest', 'PyYAML']}
(out / 'runtime.json').write_text(json.dumps({'python': sys.version, 'packages': versions, 'gpu_test': False, 'scope': 'CPU helpers, policy, style and a real pytest subprocess with a stub device backend'}, indent=2) + '\n')
raise SystemExit(any(row['exit'] for row in results) or len(results) != len(phases))
