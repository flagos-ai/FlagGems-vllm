import importlib.util
import json
import sys
import unittest
from pathlib import Path

sys.path.insert(0, '/source/tools')
spec = importlib.util.spec_from_file_location('ci_helper_negative', '/source/tools/test_ci_helpers.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
module.ConftestDeviceProbeTest.CONFTEST_PATH = Path('/baseline-conftest.py')
case = module.ConftestDeviceProbeTest('test_pytest_subprocess_async_fault_fails_and_records_json')
result = unittest.TextTestRunner(verbosity=2).run(unittest.TestSuite([case]))
matched = result.testsRun == 1 and len(result.failures) == 1 and not result.errors and '0 != 1' in result.failures[0][1]
Path('/results/baseline-async-negative.json').write_text(json.dumps({'baseline': '12210ab628e0b8f5beed55791958e3bd57accb2b', 'expected_test_failure': True, 'matched_expected_failure': matched, 'tests': result.testsRun, 'failures': len(result.failures), 'errors': len(result.errors)}, indent=2) + '\n')
raise SystemExit(not matched)
