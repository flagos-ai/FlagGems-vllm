import importlib.util,json,sys,unittest
from pathlib import Path
spec=importlib.util.spec_from_file_location('ci_range_negative','/source/tools/test_ci_rule_check_ranges.py')
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
module.RuleCheckRangesTest.WORKFLOW_PATH=Path('/baseline-rule-check.yaml')
case=module.RuleCheckRangesTest('test_pr_checks_exclude_stale_base_and_merge_only_files')
result=unittest.TextTestRunner(verbosity=2).run(unittest.TestSuite([case]))
trace=result.failures[0][1] if result.failures else ''
matched=result.testsRun==1 and len(result.failures)==1 and not result.errors and not result.skipped and '1 != 0' in trace and 'common_legacy.py' in trace and 'main_only.py' in trace
Path('/results/baseline-workflow-negative.json').write_text(json.dumps({'old_workflow_head':'317282b1b2db9647fc4f4267b0ea8288de1d5984','matched_expected_failure':matched,'tests':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'skipped':len(result.skipped),'stale_common_and_merge_only_files_wrongly_checked':matched},indent=2)+'\n')
raise SystemExit(not matched)
