import importlib.util,json,unittest
from pathlib import Path
spec=importlib.util.spec_from_file_location('ci_unit_range_negative','/source/tools/test_ci_rule_check_ranges.py')
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
module.RuleCheckRangesTest.UNIT_WORKFLOW_PATH=Path('/baseline-unittest.yaml')
case=module.RuleCheckRangesTest('test_unittest_collects_only_pr_paths_with_nul_delimiters')
result=unittest.TextTestRunner(verbosity=2).run(unittest.TestSuite([case]))
trace=result.failures[0][1] if result.failures else ''
matched=result.testsRun==1 and len(result.failures)==1 and not result.errors and not result.skipped and 'Lists differ' in trace and 'common_legacy.py' in trace and 'main_only.py' in trace and '_metax' in trace
Path('/results/baseline-unit-workflow-negative.json').write_text(json.dumps({'old_workflow_head':'541a13c849a5ff90fe2345a61089b9b807769508','matched_expected_failure':matched,'tests':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'skipped':len(result.skipped),'stale_common_main_and_vendor_paths_wrongly_selected':matched},indent=2)+'\n')
raise SystemExit(not matched)
