#!/bin/bash
set -Eeuo pipefail
cd /data/codex/fgv-revalidation-20261127/nvidia
sha256sum -c SHA256SUMS >package-check.log
[[ -f prepared.json && ! -e results/logprob ]]
exec 9>/tmp/codex-h20-gpu4.lock
flock -n 9
mkdir -p results/logprob
nvidia-smi --query-gpu=index,uuid,memory.used,utilization.gpu --format=csv,noheader,nounits >results/logprob/gpu-before.csv
awk -F, '$1+0==4{found=1;gsub(/ /,"",$2);if($2!="GPU-c7430ed7-2cb0-e6f8-11c9-515d0c13f44b"||$3+0>16||$4+0!=0)exit 1} END{if(!found)exit 1}' results/logprob/gpu-before.csv
uuid=GPU-c7430ed7-2cb0-e6f8-11c9-515d0c13f44b
nvidia-smi --query-compute-apps=gpu_uuid,pid,used_memory --format=csv,noheader >results/logprob/pids-before.csv
if grep -F "$uuid" results/logprob/pids-before.csv; then exit 1; fi
image=sha256:bd8a5d7a8774800c92d714c0c226b32c1863f929150f36efd610aebcd12a335d
[[ "$(docker image inspect "$image" --format '{{.Id}}')" == "$image" ]]
name=fgv-revalidate-1349-20261127-v1
label=fgv-revalidation-20261127-nvidia-logprob-v1
cid=$(docker create --pull=never --name "$name" --label "codex.task=$label" --gpus '"device=4"' --shm-size 4g --network none \
 -v "$PWD:/task:ro" -v "$PWD/sources/logprob:/candidate:ro" -v "$PWD/deps:/deps:ro" \
 -v /tmp/codex-flaggems-kda-1249-8d2bcdf/deps:/legacy-deps:ro \
 -v /data/codex/flaggems-vllm-h20-marlin-0d86ec1/source/.venv/lib/python3.12/site-packages/triton:/compiler/triton:ro \
 -v /data/codex/flaggems-vllm-h20-marlin-0d86ec1/source/.venv/lib/python3.12/site-packages/flagtree:/compiler/flagtree:ro \
 -v /data/codex/flaggems-vllm-h20-marlin-0d86ec1/source/.venv/lib/python3.12/site-packages/flagtree-0.7.0.dist-info:/compiler/flagtree-0.7.0.dist-info:ro \
 -v "$PWD/results/logprob:/results" -e FLAGGEMS_VENDOR=nvidia -e TORCH_DEVICE_BACKEND_AUTOLOAD=0 -e PYTHONDONTWRITEBYTECODE=1 \
 --entrypoint bash "$image" /task/inside-logprob.sh)
[[ "$cid" =~ ^[a-f0-9]{64}$ ]]
printf '%s\n' "$cid" >results/logprob/cid
owned(){ [[ "$(docker inspect "$cid" --format '{{index .Config.Labels "codex.task"}}')" == "$label" ]]; }
cleanup(){
 if owned; then
  if [[ "$(docker inspect "$cid" --format '{{.State.Running}}')" == true ]]; then docker stop --time 60 "$cid" >results/logprob/forced-stop.txt; fi
  docker inspect "$cid" --format '{{json .State}}' >results/logprob/final-state.json
  docker rm "$cid" >results/logprob/removed.txt
 fi
}
trap cleanup EXIT
set +e
timeout --signal=TERM --kill-after=65s 20m docker start -a "$cid" >results/logprob/container.log 2>&1
status=$?
set -e
printf '%s\n' "$status" >results/logprob/attach.exit
owned
docker inspect "$cid" --format '{{json .State}}' >results/logprob/state-before-cleanup.json
cleanup
trap - EXIT
docker ps -a --no-trunc --format '{{.ID}}' >results/logprob/all-container-ids-after.txt
if grep -Fx "$cid" results/logprob/all-container-ids-after.txt; then exit 1; fi
nvidia-smi --query-gpu=index,uuid,memory.used,utilization.gpu --format=csv,noheader,nounits >results/logprob/gpu-after.csv
nvidia-smi --query-compute-apps=gpu_uuid,pid,used_memory --format=csv,noheader >results/logprob/pids-after.csv
awk -F, '$1+0==4{found=1;gsub(/ /,"",$2);if($2!="GPU-c7430ed7-2cb0-e6f8-11c9-515d0c13f44b"||$3+0>16||$4+0!=0)exit 1} END{if(!found)exit 1}' results/logprob/gpu-after.csv
if grep -F "$uuid" results/logprob/pids-after.csv; then exit 1; fi
printf '%s\n' "$status" >results/logprob/exit
exit "$status"
