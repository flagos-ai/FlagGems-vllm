#!/bin/bash
set -Eeuo pipefail
cd /results
export PYTHONPATH=/compiler:/candidate/src:/candidate:/deps:/legacy-deps
export HOME=/results/home XDG_CACHE_HOME=/results/cache/xdg
export FLAGGEMS_CACHE_DIR=/results/cache/gems TRITON_CACHE_DIR=/results/cache/triton
mkdir -p "$HOME" "$XDG_CACHE_HOME" "$FLAGGEMS_CACHE_DIR" "$TRITON_CACHE_DIR"
python=/usr/bin/python3
"$python" /task/verify-source.py /candidate /task/manifest-logprob.json >source-before.json
"$python" - <<'PY' >runtime.json
import hashlib,importlib,importlib.metadata,json,os,pathlib,torch,triton,vllm,flaggems_vllm
assert torch.__version__=='2.13.0+cu130' and triton.__version__=='3.6.0' and vllm.__version__=='0.32.0'
expected={'flag-gems':'5.4.0','flagtree':'0.7.0','flagcx':'0.14.1+cuda13.3'}
for name,version in expected.items():assert importlib.metadata.version(name)==version,(name,importlib.metadata.version(name))
for name in ['VLLM_FL_FLAGOS_WHITELIST','VLLM_FL_FLAGOS_BLACKLIST','VLLM_FL_OP_WHITELIST','VLLM_FL_OP_BLACKLIST','VLLM_FL_PREFER','GEMS_CONFIG','FLAGGEMS_CONFIG']:
 assert name not in os.environ,name
logprob=importlib.import_module('flaggems_vllm.ops.logprob')
assert logprob.HAS_TLE
assert pathlib.Path(flaggems_vllm.__file__).resolve()==pathlib.Path('/candidate/src/flaggems_vllm/__init__.py')
mods={name:str(pathlib.Path(importlib.import_module(name).__file__).resolve()) for name in ['torch','triton','flagtree','flag_gems','flagcx','vllm','flaggems_vllm','flaggems_vllm.ops.logprob']}
kernel=pathlib.Path('/compiler/triton/_C/libtriton.so');assert hashlib.sha256(kernel.read_bytes()).hexdigest()=='385c1089a702a71df0ce847bdac0e71234d411396ac1bbdfe5d74bbd6528f43f'
print(json.dumps({'torch':torch.__version__,'triton':triton.__version__,'vllm':vllm.__version__,'packages':expected,'TLE':logprob.HAS_TLE,'origins':mods,'gpu':torch.cuda.get_device_name(0),'device_count':torch.cuda.device_count(),'native_reference':'installed vllm0.32','cache':{x:os.environ[x] for x in ['FLAGGEMS_CACHE_DIR','TRITON_CACHE_DIR','XDG_CACHE_HOME']}}))
PY
"$python" -m pytest /candidate/tests/test_logprob.py -q -rA -c /candidate/pytest.ini -o cache_dir=/results/cache/pytest --junitxml=/results/functional.xml >functional.log 2>&1
"$python" -m pytest /candidate/benchmark/test_logprob.py -q -s -c /candidate/pytest.ini -o cache_dir=/results/cache/pytest --level core --warmup 25 --iter 100 --record json --output /results/performance.json --junitxml=/results/performance.xml >performance.log 2>&1
"$python" /task/verify-source.py /candidate /task/manifest-logprob.json >source-after.json
