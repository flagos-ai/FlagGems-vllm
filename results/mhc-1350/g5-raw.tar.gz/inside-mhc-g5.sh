#!/bin/bash
set -Eeuo pipefail
cd /results
export PYTHONPATH=/task:/compiler:/candidate/src:/candidate:/deps:/legacy-deps
export HOME=/results/home XDG_CACHE_HOME=/results/cache/xdg
export FLAGGEMS_CACHE_DIR=/results/cache/gems TRITON_CACHE_DIR=/results/cache/triton
mkdir -p "$HOME" "$XDG_CACHE_HOME" "$FLAGGEMS_CACHE_DIR" "$TRITON_CACHE_DIR"
python=/usr/bin/python3
"$python" /task/verify-source.py /candidate /task/manifest-mhc.json >source-before.json
"$python" - <<'PY' >runtime.json
import hashlib,importlib,importlib.metadata,json,os,pathlib,torch,triton,vllm,flaggems_vllm
assert torch.__version__=='2.13.0+cu130' and triton.__version__=='3.6.0' and vllm.__version__=='0.32.0'
expected={'flag-gems':'5.4.0','flagtree':'0.7.0','flagcx':'0.14.1+cuda13.3'}
for name,version in expected.items():assert importlib.metadata.version(name)==version,(name,importlib.metadata.version(name))
for name in ['VLLM_FL_FLAGOS_WHITELIST','VLLM_FL_FLAGOS_BLACKLIST','VLLM_FL_OP_WHITELIST','VLLM_FL_OP_BLACKLIST','VLLM_FL_PREFER','GEMS_CONFIG','FLAGGEMS_CONFIG']:
 assert name not in os.environ,name
mhc=importlib.import_module('flaggems_vllm.ops.mhc.mhc_pre')
from flaggems_vllm.utils.triton_version_utils import HAS_TLE
assert HAS_TLE and mhc._IS_HOPPER
assert len(mhc.mhc_pre_packed_reader_kernel.fn.configs)==15
assert pathlib.Path(flaggems_vllm.__file__).resolve()==pathlib.Path('/candidate/src/flaggems_vllm/__init__.py')
mods={name:str(pathlib.Path(importlib.import_module(name).__file__).resolve()) for name in ['torch','triton','flagtree','flag_gems','flagcx','vllm','flaggems_vllm','flaggems_vllm.ops.mhc.mhc_pre']}
kernel=pathlib.Path('/compiler/triton/_C/libtriton.so');assert hashlib.sha256(kernel.read_bytes()).hexdigest()=='385c1089a702a71df0ce847bdac0e71234d411396ac1bbdfe5d74bbd6528f43f'
print(json.dumps({'torch':torch.__version__,'triton':triton.__version__,'vllm':vllm.__version__,'packages':expected,'TLE':HAS_TLE,'origins':mods,'gpu':torch.cuda.get_device_name(0),'device_count':torch.cuda.device_count(),'native_reference':'installed vllm0.32','cache':{x:os.environ[x] for x in ['FLAGGEMS_CACHE_DIR','TRITON_CACHE_DIR','XDG_CACHE_HOME']}}))
PY
for temperature in cold warm; do
 export PUBLIC_FGV_PHASE=norm-$temperature
 "$python" -m pytest /candidate/tests/test_mhc_with_norm.py -q -rA -c /candidate/pytest.ini -o cache_dir=/results/cache/pytest -p pytest_context_observer --junitxml=/results/norm-$temperature.xml >norm-$temperature.log 2>&1
done
export PUBLIC_FGV_PHASE=nearby
"$python" -m pytest /candidate/tests/test_mhc_ops.py /candidate/tests/test_mhc_post.py /candidate/tests/test_mhc_pre_broadcast.py /candidate/tests/test_mhc_shifted_post_pre.py -q -rA -c /candidate/pytest.ini -o cache_dir=/results/cache/pytest -p pytest_context_observer --junitxml=/results/nearby.xml >nearby.log 2>&1
"$python" - <<'PY'
import json
for phase in ['norm-cold','norm-warm','nearby']:
 p=json.load(open('/results/'+phase+'-context.json'))
 assert p['device_context_poisoned'] is False,p
PY
export HOME=/results/strong-home XDG_CACHE_HOME=/results/strong-cache/xdg
export FLAGGEMS_CACHE_DIR=/results/strong-cache/gems TRITON_CACHE_DIR=/results/strong-cache/triton
"$python" /task/hopper-source-strong15.py >strong.log 2>&1
"$python" /task/verify-source.py /candidate /task/manifest-mhc.json >source-after.json
