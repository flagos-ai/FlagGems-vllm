#!/bin/bash
set -Eeuo pipefail
cd /data/codex/fgv-revalidation-20261127/nvidia-mhc-g6-v1
sha256sum -c SHA256SUMS >package-check.log
[[ -f prepared.json && ! -e results/mhc-g6 ]]
exec 9>/tmp/codex-h20-gpu5.lock
flock -n 9
mkdir -p results/mhc-g6
nvidia-smi --query-gpu=index,uuid,memory.used,utilization.gpu --format=csv,noheader,nounits >results/mhc-g6/gpu-before.csv
awk -F, '$1+0==5{found=1;gsub(/ /,"",$2);if($2!="GPU-09e798f6-daed-4a79-839f-6b1b610d5ada"||$3+0>16||$4+0!=0)exit 1} END{if(!found)exit 1}' results/mhc-g6/gpu-before.csv
uuid=GPU-09e798f6-daed-4a79-839f-6b1b610d5ada
nvidia-smi --query-compute-apps=gpu_uuid,pid,used_memory --format=csv,noheader >results/mhc-g6/pids-before.csv
if grep -F "$uuid" results/mhc-g6/pids-before.csv; then exit 1; fi
image=sha256:bd8a5d7a8774800c92d714c0c226b32c1863f929150f36efd610aebcd12a335d
[[ "$(docker image inspect "$image" --format '{{.Id}}')" == "$image" ]]
name=fgv-revalidate-1350-g6-20261127-v1
label=fgv-revalidation-20261127-nvidia-mhc-g6-v1
cid=$(docker create --pull=never --name "$name" --label "codex.task=$label" --gpus '"device=5"' --shm-size 4g --network none \
 -v "$PWD:/task:ro" -v /data/codex/fgv-revalidation-20261127/nvidia-mhc-g5-v1/sources/mhc:/candidate:ro -v /data/codex/fgv-revalidation-20261127/nvidia/deps:/deps:ro \
 -v /tmp/codex-flaggems-kda-1249-8d2bcdf/deps:/legacy-deps:ro \
 -v /data/codex/flaggems-vllm-h20-marlin-0d86ec1/source/.venv/lib/python3.12/site-packages/triton:/compiler/triton:ro \
 -v /data/codex/flaggems-vllm-h20-marlin-0d86ec1/source/.venv/lib/python3.12/site-packages/flagtree:/compiler/flagtree:ro \
 -v /data/codex/flaggems-vllm-h20-marlin-0d86ec1/source/.venv/lib/python3.12/site-packages/flagtree-0.7.0.dist-info:/compiler/flagtree-0.7.0.dist-info:ro \
 -v "$PWD/results/mhc-g6:/results" -v "$PWD/results/mhc-g6:/probe" -e FLAGGEMS_VENDOR=nvidia -e TORCH_DEVICE_BACKEND_AUTOLOAD=0 -e PYTHONDONTWRITEBYTECODE=1 \
 --entrypoint bash "$image" /task/inside-mhc-g6.sh)
[[ "$cid" =~ ^[a-f0-9]{64}$ ]]
printf '%s\n' "$cid" >results/mhc-g6/cid
owned(){ [[ "$(docker inspect "$cid" --format '{{index .Config.Labels "codex.task"}}')" == "$label" ]]; }
cleanup(){
 if owned; then
  if [[ "$(docker inspect "$cid" --format '{{.State.Running}}')" == true ]]; then docker stop --time 60 "$cid" >results/mhc-g6/forced-stop.txt; fi
  docker inspect "$cid" --format '{{json .State}}' >results/mhc-g6/final-state.json
  docker rm "$cid" >results/mhc-g6/removed.txt
 fi
}
trap cleanup EXIT
set +e
timeout --signal=TERM --kill-after=65s 60m docker start -a "$cid" >results/mhc-g6/container.log 2>&1
status=$?
set -e
printf '%s\n' "$status" >results/mhc-g6/attach.exit
owned
docker inspect "$cid" --format '{{json .State}}' >results/mhc-g6/state-before-cleanup.json
cleanup
trap - EXIT
docker ps -a --no-trunc --format '{{.ID}}' >results/mhc-g6/all-container-ids-after.txt
if grep -Fx "$cid" results/mhc-g6/all-container-ids-after.txt; then exit 1; fi
nvidia-smi --query-gpu=index,uuid,memory.used,utilization.gpu --format=csv,noheader,nounits >results/mhc-g6/gpu-after.csv
nvidia-smi --query-compute-apps=gpu_uuid,pid,used_memory --format=csv,noheader >results/mhc-g6/pids-after.csv
awk -F, '$1+0==5{found=1;gsub(/ /,"",$2);if($2!="GPU-09e798f6-daed-4a79-839f-6b1b610d5ada"||$3+0>16||$4+0!=0)exit 1} END{if(!found)exit 1}' results/mhc-g6/gpu-after.csv
if grep -F "$uuid" results/mhc-g6/pids-after.csv; then exit 1; fi
printf '%s\n' "$status" >results/mhc-g6/exit
exit "$status"
