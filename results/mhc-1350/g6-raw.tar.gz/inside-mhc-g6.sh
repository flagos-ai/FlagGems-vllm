#!/bin/bash
set -Eeuo pipefail
cd /results
export PYTHONPATH=/task:/compiler:/candidate/src:/candidate:/deps:/legacy-deps
export HOME=/results/home XDG_CACHE_HOME=/results/cache/xdg
export FLAGGEMS_CACHE_DIR=/results/cache/gems TRITON_CACHE_DIR=/results/cache/triton
mkdir -p "$HOME" "$XDG_CACHE_HOME" "$FLAGGEMS_CACHE_DIR" "$TRITON_CACHE_DIR"
python=/usr/bin/python3
"$python" /task/verify-source.py /candidate /task/manifest-mhc.json >source-before.json
"$python" - <<'PY' >runtime.json
import hashlib,importlib,importlib.metadata,json,os,pathlib,torch,triton,vllm,flaggems_vllm
assert torch.__version__=='2.13.0+cu130' and triton.__version__=='3.6.0' and vllm.__version__=='0.32.0'
expected={'flag-gems':'5.4.0','flagtree':'0.7.0','flagcx':'0.14.1+cuda13.3'}
for name,version in expected.items():assert importlib.metadata.version(name)==version,(name,importlib.metadata.version(name))
for name in ['VLLM_FL_FLAGOS_WHITELIST','VLLM_FL_FLAGOS_BLACKLIST','VLLM_FL_OP_WHITELIST','VLLM_FL_OP_BLACKLIST','VLLM_FL_PREFER','GEMS_CONFIG','FLAGGEMS_CONFIG']:
 assert name not in os.environ,name
mhc=importlib.import_module('flaggems_vllm.ops.mhc.mhc_pre')
from flaggems_vllm.utils.triton_version_utils import HAS_TLE
assert HAS_TLE and mhc._IS_HOPPER
assert len(mhc.mhc_pre_packed_reader_kernel.fn.configs)==15
assert pathlib.Path(flaggems_vllm.__file__).resolve()==pathlib.Path('/candidate/src/flaggems_vllm/__init__.py')
mods={name:str(pathlib.Path(importlib.import_module(name).__file__).resolve()) for name in ['torch','triton','flagtree','flag_gems','flagcx','vllm','flaggems_vllm','flaggems_vllm.ops.mhc.mhc_pre']}
kernel=pathlib.Path('/compiler/triton/_C/libtriton.so');assert hashlib.sha256(kernel.read_bytes()).hexdigest()=='385c1089a702a71df0ce847bdac0e71234d411396ac1bbdfe5d74bbd6528f43f'
print(json.dumps({'torch':torch.__version__,'triton':triton.__version__,'vllm':vllm.__version__,'packages':expected,'TLE':HAS_TLE,'origins':mods,'gpu':torch.cuda.get_device_name(0),'device_count':torch.cuda.device_count(),'native_reference':'installed vllm0.32','cache':{x:os.environ[x] for x in ['FLAGGEMS_CACHE_DIR','TRITON_CACHE_DIR','XDG_CACHE_HOME']}}))
PY
export HOME=/results/g6-home XDG_CACHE_HOME=/results/g6-cache/xdg
export FLAGGEMS_CACHE_DIR=/results/g6-cache/gems TRITON_CACHE_DIR=/results/g6-cache/triton
"$python" - <<'PY' >native-provenance.json
import hashlib,inspect,json,pathlib
from baseline import mhc_pre as workload
native=workload.native();assert native is not None
assert native.__module__.startswith('vllm.'),(native.__module__,native.__name__)
source=pathlib.Path(inspect.getsourcefile(inspect.unwrap(native)))
assert '/vllm/' in str(source)
print(json.dumps({'resolver':workload.__file__,'native':native.__module__+'.'+native.__name__,'source_path':str(source),'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'native_is_torch_replacement':False}))
PY
"$python" /task/hopper-source-gate15.py full12-currentmain >native-g6.log 2>&1
"$python" - <<'PY' >native-g6-validation.json
import json,math,statistics,sys
p=json.load(open('/results/hopper-gate-full12-currentmain.json'))
assert p['native']==json.load(open('/results/native-provenance.json'))['native']
expected=[[t,h] for t in [512,1024,2048,8192] for h in [1280,2560,4096]]
assert [r['shape'] for r in p['rows']]==expected
ratios=[]
for row in p['rows']:
 a=row['native_samples_us'];b=row['candidate_samples_us']
 assert len(a)==len(b)==3 and all(math.isfinite(x) and x>0 for x in a+b)
 ratio=statistics.median(a)/statistics.median(b)
 assert math.isclose(ratio,row['speedup'],rel_tol=1e-12)
 ratios.append(ratio)
passed=all(x>=.9 for x in ratios)
print(json.dumps({'cases':12,'passed':sum(x>=.9 for x in ratios),'minimum':min(ratios),'ratios':ratios,'threshold':.9,'accepted':passed}))
sys.exit(0 if passed else 1)
PY
"$python" /task/verify-source.py /candidate /task/manifest-mhc.json >source-after.json
