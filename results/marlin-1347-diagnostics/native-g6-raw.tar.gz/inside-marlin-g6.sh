#!/bin/bash
set -Eeuo pipefail
cd /results
export PYTHONPATH=/task:/compiler:/candidate/src:/candidate:/deps:/legacy-deps
export HOME=/results/home XDG_CACHE_HOME=/results/cache/xdg
export FLAGGEMS_CACHE_DIR=/results/cache/gems TRITON_CACHE_DIR=/results/cache/triton
mkdir -p "$HOME" "$XDG_CACHE_HOME" "$FLAGGEMS_CACHE_DIR" "$TRITON_CACHE_DIR"
python=/usr/bin/python3
"$python" /task/verify-source.py /candidate /task/manifest-marlin.json >source-before.json
"$python" - <<'PY' >runtime.json
import hashlib,importlib,importlib.metadata,json,os,pathlib,torch,triton,vllm,flaggems_vllm
assert torch.__version__=='2.13.0+cu130' and triton.__version__=='3.6.0' and vllm.__version__=='0.32.0'
expected={'flag-gems':'5.4.0','flagtree':'0.7.0','flagcx':'0.14.1+cuda13.3'}
for name,version in expected.items():assert importlib.metadata.version(name)==version,(name,importlib.metadata.version(name))
for name in ['VLLM_FL_FLAGOS_WHITELIST','VLLM_FL_FLAGOS_BLACKLIST','VLLM_FL_OP_WHITELIST','VLLM_FL_OP_BLACKLIST','VLLM_FL_PREFER','GEMS_CONFIG','FLAGGEMS_CONFIG']:
 assert name not in os.environ,name
from flaggems_vllm.utils.triton_version_utils import HAS_TLE
from flaggems_vllm.runtime.backend import BackendArchEvent
assert HAS_TLE and BackendArchEvent().arch=='hopper'
assert pathlib.Path(flaggems_vllm.__file__).resolve()==pathlib.Path('/candidate/src/flaggems_vllm/__init__.py')
mods={name:str(pathlib.Path(importlib.import_module(name).__file__).resolve()) for name in ['torch','triton','flagtree','flag_gems','flagcx','vllm','flaggems_vllm','flaggems_vllm.ops.fused_marlin_moe']}
kernel=pathlib.Path('/compiler/triton/_C/libtriton.so');assert hashlib.sha256(kernel.read_bytes()).hexdigest()=='385c1089a702a71df0ce847bdac0e71234d411396ac1bbdfe5d74bbd6528f43f'
print(json.dumps({'torch':torch.__version__,'triton':triton.__version__,'vllm':vllm.__version__,'packages':expected,'TLE':HAS_TLE,'origins':mods,'gpu':torch.cuda.get_device_name(0),'device_count':torch.cuda.device_count(),'native_reference':'installed vllm0.32','cache':{x:os.environ[x] for x in ['FLAGGEMS_CACHE_DIR','TRITON_CACHE_DIR','XDG_CACHE_HOME']}}))
PY
"$python" - <<'PY' >native-provenance.json
import hashlib,importlib,inspect,json,pathlib
import flaggems_vllm
assert flaggems_vllm.vendor_name=='nvidia'
rows=[]
for precision in ['int8','fp8']:
 b=importlib.import_module('benchmark.test_fused_marlin_moe_w8a16_'+precision)
 assert b.HAS_VLLM_FUSED_MARLIN_MOE
 native=b.vllm_fused_marlin_moe
 assert native.__module__.startswith('vllm.')
 source=pathlib.Path(inspect.getsourcefile(inspect.unwrap(native)))
 assert '/vllm/' in str(source)
 rows.append({'precision':precision,'native':native.__module__+'.'+native.__name__,'source_path':str(source),'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'adapter':getattr(b,'_vllm_baseline_'+precision).__name__,'torch_replacement':False})
print(json.dumps(rows))
PY
"$python" /task/probe-replay-filtered.py --variant current-main122-plus-e5 --only all --identity-output /results/identities.json >native-g6.log 2>&1
"$python" - <<'PY' >native-g6-validation.json
import json,math,statistics,sys
rows=[json.loads(line) for line in open('/results/native-g6.log') if line.startswith('{')]
actual=json.load(open('/results/identities.json'))['records']
reference=json.load(open('/task/reference-all-identities.json'))['records']
assert len(actual)==len(reference)==14
for a,b in zip(actual,reference):
 for key in ['precision','shape','seed','inputs','weight_bank_sha256']:assert a[key]==b[key],(a['precision'],a['shape'],key)
accuracy=[r for r in rows if r.get('event')=='accuracy'];timing=[r for r in rows if r.get('event')=='timing']
assert len(accuracy)==len(timing)==14
ratios=[]
for a,t,i in zip(accuracy,timing,actual):
 assert a['precision']==t['precision']==i['precision'] and a['shape']==t['shape']==i['shape']
 assert math.isfinite(a['max_diff']) and a['max_diff']<.04
 assert len(t['rounds'])==3
 values=[]
 for r in t['rounds']:
  assert math.isfinite(r['native']) and math.isfinite(r['gems']) and min(r['native'],r['gems'])>0
  v=r['native']/r['gems'];assert math.isclose(v,r['speedup'],rel_tol=1e-12);values.append(v)
 ratios.append(statistics.median(values))
passed=all(x>=.9 for x in ratios)
print(json.dumps({'cases':14,'numerical_passed':14,'performance_passed':sum(x>=.9 for x in ratios),'minimum':min(ratios),'ratios':ratios,'threshold':.9,'accepted':passed,'all_frozen_input_identities_match':True}))
sys.exit(0 if passed else 1)
PY
"$python" /task/verify-source.py /candidate /task/manifest-marlin.json >source-after.json
