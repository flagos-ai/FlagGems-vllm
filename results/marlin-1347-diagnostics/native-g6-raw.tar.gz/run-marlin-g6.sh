#!/bin/bash
set -Eeuo pipefail
cd /data/codex/fgv-revalidation-20261127/nvidia-marlin-g6-v1
sha256sum -c SHA256SUMS >package-check.log
[[ -f prepared.json && ! -e results/marlin-g6 ]]
exec 9>/tmp/codex-h20-gpu6.lock
flock -n 9
mkdir -p results/marlin-g6
nvidia-smi --query-gpu=index,uuid,memory.used,utilization.gpu --format=csv,noheader,nounits >results/marlin-g6/gpu-before.csv
awk -F, '$1+0==6{found=1;gsub(/ /,"",$2);if($2!="GPU-48d06395-bc23-9c46-9bff-a17af3cc7705"||$3+0>16||$4+0!=0)exit 1} END{if(!found)exit 1}' results/marlin-g6/gpu-before.csv
uuid=GPU-48d06395-bc23-9c46-9bff-a17af3cc7705
nvidia-smi --query-compute-apps=gpu_uuid,pid,used_memory --format=csv,noheader >results/marlin-g6/pids-before.csv
if grep -F "$uuid" results/marlin-g6/pids-before.csv; then exit 1; fi
image=sha256:bd8a5d7a8774800c92d714c0c226b32c1863f929150f36efd610aebcd12a335d
[[ "$(docker image inspect "$image" --format '{{.Id}}')" == "$image" ]]
name=fgv-revalidate-1347-g6-20261127-v1
label=fgv-revalidation-20261127-nvidia-marlin-g6-v1
cid=$(docker create --pull=never --name "$name" --label "codex.task=$label" --gpus '"device=6"' --shm-size 4g --network none \
 -v "$PWD:/task:ro" -v /data/codex/fgv-revalidation-20261127/nvidia-marlin-g5-v1/sources/marlin:/candidate:ro -v /data/codex/fgv-revalidation-20261127/nvidia/deps:/deps:ro \
 -v /tmp/codex-flaggems-kda-1249-8d2bcdf/deps:/legacy-deps:ro \
 -v /data/codex/flaggems-vllm-h20-marlin-0d86ec1/source/.venv/lib/python3.12/site-packages/triton:/compiler/triton:ro \
 -v /data/codex/flaggems-vllm-h20-marlin-0d86ec1/source/.venv/lib/python3.12/site-packages/flagtree:/compiler/flagtree:ro \
 -v /data/codex/flaggems-vllm-h20-marlin-0d86ec1/source/.venv/lib/python3.12/site-packages/flagtree-0.7.0.dist-info:/compiler/flagtree-0.7.0.dist-info:ro \
 -v "$PWD/results/marlin-g6:/results" -e FLAGGEMS_VENDOR=nvidia -e TORCH_DEVICE_BACKEND_AUTOLOAD=0 -e PYTHONDONTWRITEBYTECODE=1 \
 --entrypoint bash "$image" /task/inside-marlin-g6.sh)
[[ "$cid" =~ ^[a-f0-9]{64}$ ]]
printf '%s\n' "$cid" >results/marlin-g6/cid
owned(){ [[ "$(docker inspect "$cid" --format '{{index .Config.Labels "codex.task"}}')" == "$label" ]]; }
cleanup(){
 if owned; then
  if [[ "$(docker inspect "$cid" --format '{{.State.Running}}')" == true ]]; then docker stop --time 60 "$cid" >results/marlin-g6/forced-stop.txt; fi
  docker inspect "$cid" --format '{{json .State}}' >results/marlin-g6/final-state.json
  docker rm "$cid" >results/marlin-g6/removed.txt
 fi
}
trap cleanup EXIT
set +e
timeout --signal=TERM --kill-after=65s 60m docker start -a "$cid" >results/marlin-g6/container.log 2>&1
status=$?
set -e
printf '%s\n' "$status" >results/marlin-g6/attach.exit
owned
docker inspect "$cid" --format '{{json .State}}' >results/marlin-g6/state-before-cleanup.json
cleanup
trap - EXIT
docker ps -a --no-trunc --format '{{.ID}}' >results/marlin-g6/all-container-ids-after.txt
if grep -Fx "$cid" results/marlin-g6/all-container-ids-after.txt; then exit 1; fi
nvidia-smi --query-gpu=index,uuid,memory.used,utilization.gpu --format=csv,noheader,nounits >results/marlin-g6/gpu-after.csv
nvidia-smi --query-compute-apps=gpu_uuid,pid,used_memory --format=csv,noheader >results/marlin-g6/pids-after.csv
awk -F, '$1+0==6{found=1;gsub(/ /,"",$2);if($2!="GPU-48d06395-bc23-9c46-9bff-a17af3cc7705"||$3+0>16||$4+0!=0)exit 1} END{if(!found)exit 1}' results/marlin-g6/gpu-after.csv
if grep -F "$uuid" results/marlin-g6/pids-after.csv; then exit 1; fi
printf '%s\n' "$status" >results/marlin-g6/exit
exit "$status"
