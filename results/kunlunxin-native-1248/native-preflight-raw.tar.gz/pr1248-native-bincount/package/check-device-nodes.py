import json
import os
import sys
from pathlib import Path

vendor=sys.argv[1]
if vendor=='ascend':
    nodes=sorted(p.name for p in Path('/dev').glob('davinci[0-9]*'))
    assert nodes==['davinci0'],nodes
    assert 1000 in os.getgroups(),os.getgroups()
    selected=['/dev/davinci0','/dev/davinci_manager','/dev/devmm_svm','/dev/hisi_hdc']
else:
    nodes=sorted(p.name for p in Path('/dev').glob('xpu[0-9]*'))
    assert nodes==['xpu4'],nodes
    selected=['/dev/xpu4','/dev/xpuctrl','/dev/xdrdrv']
for name in selected:
    assert Path(name).is_char_device() and os.access(name,os.R_OK|os.W_OK),name
print(json.dumps({'vendor':vendor,'compute_nodes':nodes,'groups':os.getgroups(),'selected_device_nodes_accessible':True,'no_backend_imported':True}))
