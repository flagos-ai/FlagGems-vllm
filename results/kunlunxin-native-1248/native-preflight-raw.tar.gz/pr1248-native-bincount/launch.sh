#!/usr/bin/env bash
set -Eeuo pipefail
op=$1
[[ "$op" == grammar || "$op" == penalties || "$op" == bincount ]]
work="/data/codex/fgv-revalidation-20261127/pr1248-native-$op"
cd "$work"
[[ ! -e started.utc && ! -e results ]]
sha256sum -c SHA256SUMS > package-verified.log
exec 8>/tmp/codex-p800-4-6.lock; flock -n 8
exec 9>/tmp/codex-fgv-p800-4.lock; flock -n 9
python3 check-resources.py kunlunxin > admission.json
mkdir -p results/cache/triton results/cache/xdg results/cache/flaggems
name="codex-fgv-pr1248-native-$op-20261127"
label="fgv-pr1248-native-$op-20261127"
if docker container inspect "$name" >/dev/null 2>&1; then exit 13; fi
cid=$(docker create --pull=never --name "$name" --label "codex.task=$label" --runtime=runc --network none --ipc private --shm-size 2g --cpus 4 --memory 16g --cap-drop ALL --security-opt no-new-privileges --ulimit memlock=-1 --device /dev/xpuctrl --device /dev/xpu4 --device /dev/xdrdrv -v "$work/package:/task:ro" -v "$work/results:/results" --entrypoint /usr/bin/env sha256:562f5a483b37b5dc6b143cbb5df5ef7707e72ddc2dc6f3603605f2829e0a026c -u BASH_ENV /bin/bash --noprofile --norc -c 'set -e; if test -r /etc/bash_env.sh; then source /etc/bash_env.sh; fi; unset BASH_ENV VLLM_FL_FLAGOS_WHITELIST VLLM_FL_FLAGOS_BLACKLIST VLLM_FL_FLAGOS_BLACKLIST_APPEND FLAGCX_PATH; export PATH=/flagos/bin:$PATH CUDA_VISIBLE_DEVICES=0 VLLM_PLUGINS="" USE_FLAGGEMS=0 GEMS_VENDOR=kunlunxin FLAGGEMS_VENDOR=kunlunxin DNN_VENDOR=kunlunxin; export TRITON_CACHE_DIR=/results/cache/triton FLAGGEMS_CACHE_DIR=/results/cache/flaggems XDG_CACHE_HOME=/results/cache/xdg PYTHONDONTWRITEBYTECODE=1; python -I -S -B /task/check-device-nodes.py kunlunxin > /results/device-node-scope.json; exec python -B /task/preflight.py "$1"' bash "$op")
[[ "$cid" =~ ^[a-f0-9]{64}$ ]]
printf '%s\n' "$cid" > results/container.cid
cleanup() {
  local actual
  actual=$(docker inspect --format '{{.Id}} {{index .Config.Labels "codex.task"}}' "$cid") || return 1
  [[ "$actual" == "$cid $label" ]] || return 1
  docker inspect "$cid" --format '{{json .State}}' > results/container-final-state.json
  if [[ "$(docker inspect "$cid" --format '{{.State.Running}}')" == true ]]; then
    printf 'true\n' > results/forced-owned-stop
    docker stop --time 15 "$cid" >/dev/null
  fi
  docker rm "$cid" >/dev/null
  docker ps -aq --no-trunc > results/docker-container-ids-after.txt || return 1
  if grep -Fxq "$cid" results/docker-container-ids-after.txt; then return 1; fi
  printf 'true\n' > results/owned-cid-absent
}
trap cleanup EXIT
date -u -Is > started.utc
set +e
timeout --signal=TERM --kill-after=15s 300s docker start --attach "$cid" > results/native.log 2>&1
result=$?
set -e
printf '%s\n' "$result" > results/attach.exit
cleanup
trap - EXIT
python3 check-resources.py kunlunxin > results/post-resources.json
date -u -Is > finished.utc
exit "$result"
