set -euo pipefail
for op in grammar penalties bincount; do
  work=/data/codex/fgv-revalidation-20261127/pr1248-native-$op
  cd "$work"
  set +e
  bash launch.sh "$op" > controller.log 2>&1
  result=$?
  set -e
  printf '%s\n' "$result" > controller.exit
  if [[ ! -f finished.utc || ! -f results/owned-cid-absent || -e results/forced-owned-stop ]]; then exit 14; fi
  python3 - "$work" <<'PY'
import json,sys
from pathlib import Path
p=Path(sys.argv[1])
assert (p/'results/owned-cid-absent').read_text().strip()=='true'
assert json.loads((p/'results/post-resources.json').read_text())['passed']
PY
done

