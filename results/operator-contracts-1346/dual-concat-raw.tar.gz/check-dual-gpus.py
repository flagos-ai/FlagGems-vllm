import csv
import json
import sys
from pathlib import Path

expected = {
    4: 'GPU-c7430ed7-2cb0-e6f8-11c9-515d0c13f44b',
    5: 'GPU-09e798f6-daed-4a79-839f-6b1b610d5ada',
}
found = {}
for row in csv.reader(Path(sys.argv[1]).read_text().splitlines()):
    index = int(row[0])
    if index in expected:
        assert row[1].strip() == expected[index], row
        assert int(row[2]) <= 16 and int(row[3]) == 0, row
        found[index] = row
assert set(found) == set(expected), found
for row in csv.reader(Path(sys.argv[2]).read_text().splitlines()):
    assert row[0].strip() not in expected.values(), row
print(json.dumps({'selected':found,'both_idle_no_compute_pid':True}))
