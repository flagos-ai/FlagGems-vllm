#!/bin/bash
set -Eeuo pipefail
case_id="$1"
cd /results
export PYTHONPATH=/compiler:/candidate/src:/candidate:/deps:/legacy-deps:/task
export HOME=/results/home XDG_CACHE_HOME=/results/cache/preflight/xdg
export FLAGGEMS_CACHE_DIR=/results/cache/preflight/gems TRITON_CACHE_DIR=/results/cache/preflight/triton
mkdir -p "$HOME" "$XDG_CACHE_HOME" "$FLAGGEMS_CACHE_DIR" "$TRITON_CACHE_DIR"
python=/usr/bin/python3
finish(){ status=$?; "$python" /task/verify-source.py /candidate "/task/manifest-$case_id.json" >source-after.json || status=1; printf '%s\n' "$status" >inside.exit; exit "$status"; }
trap finish EXIT
"$python" /task/verify-source.py /candidate "/task/manifest-$case_id.json" >source-before.json
"$python" - "$case_id" <<'PY' >runtime.json
import hashlib,importlib,importlib.metadata,json,os,pathlib,sys,torch,triton,vllm,flaggems_vllm
assert torch.__version__=='2.13.0+cu130' and triton.__version__=='3.6.0' and vllm.__version__=='0.32.0'
assert torch.cuda.device_count()==1
expected={'flag-gems':'5.4.0','flagtree':'0.7.0','flagcx':'0.14.1+cuda13.3'}
for name,version in expected.items():assert importlib.metadata.version(name)==version,(name,importlib.metadata.version(name))
for name in ['VLLM_FL_FLAGOS_WHITELIST','VLLM_FL_FLAGOS_BLACKLIST','VLLM_FL_OP_WHITELIST','VLLM_FL_OP_BLACKLIST','VLLM_FL_PREFER','GEMS_CONFIG','FLAGGEMS_CONFIG']:
 assert name not in os.environ,name
assert pathlib.Path(flaggems_vllm.__file__).resolve()==pathlib.Path('/candidate/src/flaggems_vllm/__init__.py')
mods={name:str(pathlib.Path(importlib.import_module(name).__file__).resolve()) for name in ['torch','triton','flagtree','flag_gems','flagcx','vllm','flaggems_vllm']}
kernel=pathlib.Path('/compiler/triton/_C/libtriton.so');assert hashlib.sha256(kernel.read_bytes()).hexdigest()=='385c1089a702a71df0ce847bdac0e71234d411396ac1bbdfe5d74bbd6528f43f'
fla=importlib.import_module('flaggems_vllm.ops.FLA')
public_fla=flaggems_vllm.fused_recurrent_kda is fla.fused_recurrent_kda
if sys.argv[1]=='1345':assert public_fla
bounded=importlib.import_module('flaggems_vllm.ops.kda_bounded')
assert bounded.chunk_kda_with_safe_gate._is_available() is True
assert bounded.fused_recurrent_kda._is_available() is True
prefill=bounded._prefill_core();recurrent=bounded._recurrent_core()
def arg_names(kernel):
 while not hasattr(kernel,'arg_names'):kernel=kernel.fn
 return list(kernel.arg_names)
capabilities={'prefill_available':True,'recurrent_available':True,'prefill_arg_names':[arg_names(k) for k in prefill[0]],'recurrent_arg_names':arg_names(recurrent),'native_kda_module':importlib.import_module('vllm.third_party.flash_linear_attention.ops.kda').__file__}
print(json.dumps({'bounded_core_g1':capabilities}))
print(json.dumps({'torch':torch.__version__,'triton':triton.__version__,'vllm':vllm.__version__,'packages':expected,'origins':mods,'gpu':torch.cuda.get_device_name(0),'device_count':torch.cuda.device_count(),'native_reference':'installed vllm0.32','public_recurrent_is_FLA':public_fla,'use_gems_export':hasattr(flaggems_vllm,'use_gems'),'cache':{x:os.environ[x] for x in ['FLAGGEMS_CACHE_DIR','TRITON_CACHE_DIR','XDG_CACHE_HOME']}}))
PY
if [[ "$case_id" == 1345 ]]; then
 phases=(recurrent bounded)
 modules=(tests/test_FLA/test_fused_recurrent_kda.py tests/test_kda_bounded.py)
elif [[ "$case_id" == 1346 ]]; then
 phases=(bincount concat bounded tle)
 modules=(tests/test_bincount.py tests/test_concat_mla_q.py tests/test_kda_bounded.py tests/test_tle_capabilities.py)
else
 echo 'Unsupported public GPU phase' >&2; exit 2
fi
for i in "${!phases[@]}"; do
 phase="${phases[$i]}"
 export PUBLIC_FGV_PHASE="$phase"
 export XDG_CACHE_HOME="/results/cache/$phase/xdg" FLAGGEMS_CACHE_DIR="/results/cache/$phase/gems" TRITON_CACHE_DIR="/results/cache/$phase/triton"
 mkdir -p "$XDG_CACHE_HOME" "$FLAGGEMS_CACHE_DIR" "$TRITON_CACHE_DIR"
 set +e
 "$python" -m pytest "/candidate/${modules[$i]}" -q -rA -p pytest_context_observer -c /candidate/pytest.ini -o "cache_dir=/results/cache/$phase/pytest" "--junitxml=/results/$phase.xml" >"$phase.log" 2>&1
 status=$?
 set -e
 printf '%s\n' "$status" >"$phase.exit"
 "$python" - "$phase" <<'PY'
import json,pathlib,sys
data=json.loads(pathlib.Path('/results',sys.argv[1]+'-context.json').read_text())
assert data['conftest']=='/candidate/tests/conftest.py' and data['device_context_poisoned'] is False,data
PY
 [[ "$status" -eq 0 ]] || exit "$status"
done
