import json
import os
from pathlib import Path


def pytest_sessionfinish(session, exitstatus):
    target = Path('/candidate/tests/conftest.py')
    matches = [p for p in session.config.pluginmanager.get_plugins()
               if getattr(p, '__file__', None) and Path(p.__file__).resolve() == target]
    assert len(matches) == 1, 'Expected the actual candidate tests/conftest.py'
    poisoned = getattr(matches[0], '_DEVICE_CONTEXT_DEAD')
    assert type(poisoned) is bool
    path = Path('/results') / (os.environ['PUBLIC_FGV_PHASE'] + '-context.json')
    path.write_text(json.dumps({'conftest': str(target), 'device_context_poisoned': poisoned,
                                'pytest_exitstatus': int(exitstatus)}, indent=2) + '\n')
