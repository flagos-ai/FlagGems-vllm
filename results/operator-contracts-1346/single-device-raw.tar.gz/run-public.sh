#!/bin/bash
set -Eeuo pipefail
case_id="$1"
[[ "$case_id" == 1346 ]]
cd /data/codex/fgv-revalidation-20261127/public-integration1346-v2
sha256sum -c SHA256SUMS >"package-check-$case_id.log"
[[ -f prepared.json && ! -e results/"$case_id" ]]
exec 9>/tmp/codex-h20-gpu4.lock
flock -n 9
mkdir -p results/"$case_id"
nvidia-smi --query-gpu=index,uuid,memory.used,utilization.gpu --format=csv,noheader,nounits >results/"$case_id"/gpu-before.csv
awk -F, '$1+0==4{found=1;gsub(/ /,"",$2);if($2!="GPU-c7430ed7-2cb0-e6f8-11c9-515d0c13f44b"||$3+0>16||$4+0!=0)exit 1} END{if(!found)exit 1}' results/"$case_id"/gpu-before.csv
uuid=GPU-c7430ed7-2cb0-e6f8-11c9-515d0c13f44b
nvidia-smi --query-compute-apps=gpu_uuid,pid,used_memory --format=csv,noheader >results/"$case_id"/pids-before.csv
if grep -F "$uuid" results/"$case_id"/pids-before.csv; then exit 1; fi
image=sha256:bd8a5d7a8774800c92d714c0c226b32c1863f929150f36efd610aebcd12a335d
[[ "$(docker image inspect "$image" --format '{{.Id}}')" == "$image" ]]
name=fgv-revalidate-public-$case_id-20261127-integration1346-v2
label=fgv-revalidation-20261127-public-$case_id-v1
cid=$(docker create --pull=never --name "$name" --label "codex.task=$label" --gpus '"device=4"' --shm-size 4g --network none \
 -v "$PWD:/task:ro" -v "$PWD/sources/"$case_id":/candidate:ro" -v /data/codex/fgv-revalidation-20261127/nvidia/deps:/deps:ro \
 -v /tmp/codex-flaggems-kda-1249-8d2bcdf/deps:/legacy-deps:ro \
 -v /data/codex/flaggems-vllm-h20-marlin-0d86ec1/source/.venv/lib/python3.12/site-packages/triton:/compiler/triton:ro \
 -v /data/codex/flaggems-vllm-h20-marlin-0d86ec1/source/.venv/lib/python3.12/site-packages/flagtree:/compiler/flagtree:ro \
 -v /data/codex/flaggems-vllm-h20-marlin-0d86ec1/source/.venv/lib/python3.12/site-packages/flagtree-0.7.0.dist-info:/compiler/flagtree-0.7.0.dist-info:ro \
 -v "$PWD/results/"$case_id":/results" -e FLAGGEMS_VENDOR=nvidia -e TORCH_DEVICE_BACKEND_AUTOLOAD=0 -e PYTHONDONTWRITEBYTECODE=1 \
 --entrypoint bash "$image" /task/inside-public.sh "$case_id")
[[ "$cid" =~ ^[a-f0-9]{64}$ ]]
printf '%s\n' "$cid" >results/"$case_id"/cid
owned(){ [[ "$(docker inspect "$cid" --format '{{index .Config.Labels "codex.task"}}')" == "$label" ]]; }
cleanup(){
 if owned; then
  if [[ "$(docker inspect "$cid" --format '{{.State.Running}}')" == true ]]; then docker stop --time 60 "$cid" >results/"$case_id"/forced-stop.txt; fi
  docker inspect "$cid" --format '{{json .State}}' >results/"$case_id"/final-state.json
  docker rm "$cid" >results/"$case_id"/removed.txt
 fi
}
trap cleanup EXIT
set +e
timeout --signal=TERM --kill-after=65s 20m docker start -a "$cid" >results/"$case_id"/container.log 2>&1
status=$?
set -e
printf '%s\n' "$status" >results/"$case_id"/attach.exit
owned
docker inspect "$cid" --format '{{json .State}}' >results/"$case_id"/state-before-cleanup.json
cleanup
trap - EXIT
docker ps -a --no-trunc --format '{{.ID}}' >results/"$case_id"/all-container-ids-after.txt
if grep -Fx "$cid" results/"$case_id"/all-container-ids-after.txt; then exit 1; fi
nvidia-smi --query-gpu=index,uuid,memory.used,utilization.gpu --format=csv,noheader,nounits >results/"$case_id"/gpu-after.csv
nvidia-smi --query-compute-apps=gpu_uuid,pid,used_memory --format=csv,noheader >results/"$case_id"/pids-after.csv
awk -F, '$1+0==4{found=1;gsub(/ /,"",$2);if($2!="GPU-c7430ed7-2cb0-e6f8-11c9-515d0c13f44b"||$3+0>16||$4+0!=0)exit 1} END{if(!found)exit 1}' results/"$case_id"/gpu-after.csv
if grep -F "$uuid" results/"$case_id"/pids-after.csv; then exit 1; fi
printf '%s\n' "$status" >results/"$case_id"/exit
exit "$status"
