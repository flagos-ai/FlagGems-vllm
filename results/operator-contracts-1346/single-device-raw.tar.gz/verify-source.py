import hashlib,json,pathlib,sys
source=pathlib.Path(sys.argv[1]);manifest=json.loads(pathlib.Path(sys.argv[2]).read_text())
for name,expected in manifest.items():
 p=source/name
 if 'symlink' in expected:assert p.is_symlink() and p.readlink().as_posix()==expected['symlink'],name
 else:assert p.is_file() and hashlib.sha256(p.read_bytes()).hexdigest()==expected['sha256'],name
print(json.dumps({'source':str(source),'files':len(manifest),'passed':True}))
