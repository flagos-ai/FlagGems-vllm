#!/bin/bash
set -Eeuo pipefail
case_id="$1"
cd /results
export PYTHONPATH=/compiler:/candidate/src:/candidate:/deps:/legacy-deps:/task
export HOME=/results/home XDG_CACHE_HOME=/results/cache/preflight/xdg
export FLAGGEMS_CACHE_DIR=/results/cache/preflight/gems TRITON_CACHE_DIR=/results/cache/preflight/triton
mkdir -p "$HOME" "$XDG_CACHE_HOME" "$FLAGGEMS_CACHE_DIR" "$TRITON_CACHE_DIR"
python=/usr/bin/python3
finish(){ status=$?; "$python" /task/verify-source.py /candidate "/task/manifest-$case_id.json" >source-after.json || status=1; printf '%s\n' "$status" >inside.exit; exit "$status"; }
trap finish EXIT
"$python" /task/verify-source.py /candidate "/task/manifest-$case_id.json" >source-before.json
"$python" - "$case_id" <<'PY' >runtime.json
import hashlib,importlib,importlib.metadata,json,os,pathlib,sys,torch,triton,vllm,flaggems_vllm
assert torch.__version__=='2.13.0+cu130' and triton.__version__=='3.6.0' and vllm.__version__=='0.32.0'
assert torch.cuda.device_count()==1
expected={'flag-gems':'5.4.0','flagtree':'0.7.0','flagcx':'0.14.1+cuda13.3'}
for name,version in expected.items():assert importlib.metadata.version(name)==version,(name,importlib.metadata.version(name))
for name in ['VLLM_FL_FLAGOS_WHITELIST','VLLM_FL_FLAGOS_BLACKLIST','VLLM_FL_OP_WHITELIST','VLLM_FL_OP_BLACKLIST','VLLM_FL_PREFER','GEMS_CONFIG','FLAGGEMS_CONFIG']:
 assert name not in os.environ,name
assert pathlib.Path(flaggems_vllm.__file__).resolve()==pathlib.Path('/candidate/src/flaggems_vllm/__init__.py')
mods={name:str(pathlib.Path(importlib.import_module(name).__file__).resolve()) for name in ['torch','triton','flagtree','flag_gems','flagcx','vllm','flaggems_vllm']}
kernel=pathlib.Path('/compiler/triton/_C/libtriton.so');assert hashlib.sha256(kernel.read_bytes()).hexdigest()=='385c1089a702a71df0ce847bdac0e71234d411396ac1bbdfe5d74bbd6528f43f'
fla=importlib.import_module('flaggems_vllm.ops.FLA')
public_fla=flaggems_vllm.fused_recurrent_kda is fla.fused_recurrent_kda
if sys.argv[1]=='1345':assert public_fla
print(json.dumps({'torch':torch.__version__,'triton':triton.__version__,'vllm':vllm.__version__,'packages':expected,'origins':mods,'gpu':torch.cuda.get_device_name(0),'device_count':torch.cuda.device_count(),'native_reference':'installed vllm0.32','public_recurrent_is_FLA':public_fla,'use_gems_export':hasattr(flaggems_vllm,'use_gems'),'cache':{x:os.environ[x] for x in ['FLAGGEMS_CACHE_DIR','TRITON_CACHE_DIR','XDG_CACHE_HOME']}}))
PY
"$python" - <<'PY' >native-reference.json
import hashlib,importlib,json,pathlib,vllm
benchmark=importlib.import_module('benchmark.test_bad_words')
native_module=importlib.import_module('vllm.v1.worker.gpu.sample.bad_words')
reference=benchmark.apply_bad_words_reference
assert reference is not None and reference is native_module.apply_bad_words
native_path=pathlib.Path(native_module.__file__).resolve()
assert native_path.is_relative_to(pathlib.Path(vllm.__file__).resolve().parent)
assert vllm.__version__=='0.32.0'
assert len(benchmark.WORKLOADS)==15 and len(benchmark.MATCH_PATTERNS)==3
print(json.dumps({'native_version':vllm.__version__,'module':native_module.__name__,'source':str(native_path),'source_sha256':hashlib.sha256(native_path.read_bytes()).hexdigest(),'reference_is_actual_native':True,'workloads':len(benchmark.WORKLOADS),'match_patterns':benchmark.MATCH_PATTERNS,'expected_combinations':45}))
PY
phase=accuracy
export PUBLIC_FGV_PHASE="$phase"
export XDG_CACHE_HOME="/results/cache/$phase/xdg" FLAGGEMS_CACHE_DIR="/results/cache/$phase/gems" TRITON_CACHE_DIR="/results/cache/$phase/triton"
mkdir -p "$XDG_CACHE_HOME" "$FLAGGEMS_CACHE_DIR" "$TRITON_CACHE_DIR"
set +e
"$python" -m pytest /candidate/tests/test_bad_words.py -q -rA -p pytest_context_observer -c /candidate/pytest.ini -o cache_dir=/results/cache/accuracy/pytest --junitxml=/results/accuracy.xml >accuracy.log 2>&1
status=$?
set -e
printf '%s\n' "$status" >accuracy.exit
"$python" - <<'PY'
import json,pathlib
data=json.loads(pathlib.Path('/results/accuracy-context.json').read_text())
assert data['conftest']=='/candidate/tests/conftest.py' and data['device_context_poisoned'] is False,data
PY
[[ "$status" -eq 0 ]] || exit "$status"
phase=performance
export XDG_CACHE_HOME="/results/cache/$phase/xdg" FLAGGEMS_CACHE_DIR="/results/cache/$phase/gems" TRITON_CACHE_DIR="/results/cache/$phase/triton"
mkdir -p "$XDG_CACHE_HOME" "$FLAGGEMS_CACHE_DIR" "$TRITON_CACHE_DIR"
set +e
"$python" -m pytest /candidate/benchmark/test_bad_words.py -q -s -c /candidate/pytest.ini -o cache_dir=/results/cache/performance/pytest --level core --warmup 25 --iter 100 --record json --output /results/performance.json --junitxml=/results/performance.xml >performance.log 2>&1
status=$?
set -e
printf '%s\n' "$status" >performance.exit
[[ "$status" -eq 0 ]] || exit "$status"
"$python" - <<'PY' >performance-completeness.json
import importlib,json,math,pathlib
benchmark=importlib.import_module('benchmark.test_bad_words')
entry=json.loads(pathlib.Path('/results/performance.json').read_text())['apply_bad_words']
assert entry['result']=='passed',entry
details=entry['details'];assert len(details)==1
rows=details[0]['result'];assert len(rows)==45,len(rows)
expected={(w.name,m) for w in benchmark.WORKLOADS for m in benchmark.MATCH_PATTERNS}
actual={tuple(row['shape_detail'][:2]) for row in rows};assert actual==expected
ratios=[]
for row in rows:
 assert not row.get('error_msg'),row
 for key in ['latency_base','latency']:
  assert isinstance(row[key],(int,float)) and math.isfinite(row[key]) and row[key]>0,row
 ratio=row['latency_base']/row['latency'];ratios.append({'shape':row['shape_detail'],'native_ms':row['latency_base'],'candidate_ms':row['latency'],'ratio':ratio})
print(json.dumps({'rows':len(rows),'all_original_combinations_present':True,'all_native_and_candidate_latencies_finite_positive':True,'minimum_ratio':min(row['ratio'] for row in ratios),'ratio_ge_0_9_count':sum(row['ratio']>=.9 for row in ratios),'ratios':ratios,'scope':'benchmark reference and functional compatibility; this receipt does not assert a new kernel performance Gate'},indent=2))
PY
