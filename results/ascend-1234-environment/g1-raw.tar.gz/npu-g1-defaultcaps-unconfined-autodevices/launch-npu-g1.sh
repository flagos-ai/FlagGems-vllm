#!/usr/bin/env bash
set -Eeuo pipefail
mode=$1
[[ "$mode" == defaultcaps-unconfined-autodevices ]]
work="/data/codex/fgv-revalidation-20261127/npu-g1-$mode"
cd "$work"
[[ ! -e started.utc && ! -e results ]]
sha256sum -c SHA256SUMS > package-verified.log
exec 8>/tmp/codex-fgv-ascend-chip0.lock; flock -n 8
exec 9>/tmp/codex-fgv-ascend-chip1.lock; flock -n 9
python3 check-resources.py ascend > admission.json
mkdir results
name="codex-fgv-npu-g1-$mode-20261127"
label="fgv-npu-g1-$mode-20261127"
if docker container inspect "$name" >/dev/null 2>&1; then exit 13; fi
security=()
if [[ "$mode" == defaultcaps-unconfined-autodevices ]]; then security=(--security-opt seccomp=unconfined); fi
cid=$(docker create --pull=never --name "$name" --label "codex.task=$label" --runtime=ascend --network none --ipc private --shm-size 256m --cpus 2 --memory 8g --group-add 1000 --env ASCEND_VISIBLE_DEVICES=0 --security-opt no-new-privileges "${security[@]}" -v /usr/local/Ascend/driver:/usr/local/Ascend/driver:ro -v /etc/ascend_install.info:/etc/ascend_install.info:ro -v /usr/local/bin/npu-smi:/usr/local/bin/npu-smi:ro -v "$work/package:/task:ro" -v "$work/results:/results" --entrypoint /usr/bin/env sha256:89bccfcc5fbe47ff84191d0cc54f0e8a574275282b8504f959837ebbd5b3a12d -u BASH_ENV /bin/bash --noprofile --norc -c 'set -e; if test -r /etc/bash_env.sh; then source /etc/bash_env.sh; fi; unset BASH_ENV; export PATH=/flagos/bin:$PATH ASCEND_RT_VISIBLE_DEVICES=0; exec python -B /task/npu-g1-probe.py "$1"' bash "$mode")
[[ "$cid" =~ ^[a-f0-9]{64}$ ]]
printf '%s\n' "$cid" > results/container.cid
cleanup() {
  local actual
  actual=$(docker inspect --format '{{.Id}} {{index .Config.Labels "codex.task"}}' "$cid") || return 1
  [[ "$actual" == "$cid $label" ]] || return 1
  docker inspect "$cid" --format '{{json .State}}' > results/container-final-state.json
  if [[ "$(docker inspect "$cid" --format '{{.State.Running}}')" == true ]]; then
    printf 'true\n' > results/forced-owned-stop
    docker stop --time 15 "$cid" >/dev/null
  fi
  docker rm "$cid" >/dev/null
  docker ps -aq --no-trunc > results/docker-container-ids-after.txt || return 1
  if grep -Fxq "$cid" results/docker-container-ids-after.txt; then return 1; fi
  printf 'true\n' > results/owned-cid-absent
}
trap cleanup EXIT
date -u -Is > started.utc
set +e
timeout --signal=TERM --kill-after=15s 180s docker start --attach "$cid" > results/native.log 2>&1
result=$?
set -e
printf '%s\n' "$result" > results/attach.exit
cleanup
trap - EXIT
python3 check-resources.py ascend > results/post-resources.json
date -u -Is > finished.utc
exit "$result"
