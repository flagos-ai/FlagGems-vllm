import json
import re
import subprocess
import sys

vendor=sys.argv[1]
if vendor=='ascend':
    raw=subprocess.check_output(['npu-smi','info'],text=True)
    selected={}
    for line in raw.splitlines():
        parts=line.split('|')
        if len(parts)!=5 or not re.fullmatch(r'\s*\d+\s+\d+\s*',parts[1]):continue
        chip,physical=map(int,parts[1].split())
        if physical not in (0,1):continue
        numbers=list(map(int,re.findall(r'\d+',parts[3])))
        assert len(numbers)==5 and numbers[-1]==65536,(physical,numbers)
        selected[physical]={'util':numbers[0],'memory_MiB':numbers[-2]}
    assert set(selected)=={0,1},selected
    for chip in (0,1):
        query=subprocess.check_output(['npu-smi','info','-t','proc-mem','-i','0','-c',str(chip)],text=True)
        assert query.strip()=='No process in device.',query
        assert selected[chip]['util']==0 and selected[chip]['memory_MiB']<4096,selected
else:
    raw=subprocess.check_output(['xpu-smi'],text=True)
    lines=raw.splitlines(); selected={}
    for i,line in enumerate(lines):
        match=re.match(r'\|\s+([46])\s+P800\b',line)
        if not match:continue
        mem=re.search(r'(\d+)MiB\s*/\s*(\d+)MiB',lines[i+1])
        util=re.search(r'(\d+)%',lines[i+1])
        assert mem and util and int(mem[2])==98304,lines[i+1]
        selected[int(match[1])]={'util':int(util[1]),'memory_MiB':int(mem[1])}
    assert selected=={4:{'util':0,'memory_MiB':0},6:{'util':0,'memory_MiB':0}},selected
    assert '| Processes:' in raw and 'No running processes found' in raw.split('| Processes:',1)[1],raw
print(json.dumps({'vendor':vendor,'selected':selected,'no_processes':True,'passed':True}))
