import hashlib
import json
import os
import sys
import traceback
from pathlib import Path

out=Path('/results/g1.json')
report={'phase':'device_identity_only','tensor_allocation_called':False,'mode':sys.argv[1]}
try:
    nodes=sorted(p.name for p in Path('/dev').glob('davinci[0-9]*'))
    assert nodes==['davinci0'],nodes
    assert 1000 in os.getgroups(),os.getgroups()
    status={}
    for line in Path('/proc/self/status').read_text().splitlines():
        if line.startswith(('CapEff:','Seccomp:')):
            key,value=line.split(':',1);status[key]=value.strip()
    report.update({'compute_nodes':nodes,'groups':os.getgroups(),'process_security':status,'ASCEND_VISIBLE_DEVICES':os.environ.get('ASCEND_VISIBLE_DEVICES'),'ASCEND_RT_VISIBLE_DEVICES':os.environ.get('ASCEND_RT_VISIBLE_DEVICES')})
    assert report['ASCEND_VISIBLE_DEVICES']=='0' and report['ASCEND_RT_VISIBLE_DEVICES']=='0'
    import torch
    import torch_npu
    report['torch']=torch.__version__
    report['count']=torch.npu.device_count()
    if report['count']==1:
        report['device_name']=torch.npu.get_device_name(0)
    assert not any(m.startswith(('flaggems_vllm','vllm_fl')) for m in sys.modules)
    report['provider_imported']=False
    libraries=set()
    for line in Path('/proc/self/maps').read_text().splitlines():
        if any(s in line for s in ['libascend_hal.so','libascendcl.so','libdrvdsmi_host.so']):
            path=line.split()[-1]
            if path.startswith('/') and Path(path).is_file():libraries.add(path)
    report['mapped_sdk_libraries']={p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in sorted(libraries)}
    assert report['count']==1,report['count']
    report['passed']=True
except Exception as exc:
    report['passed']=False
    report['error']={'type':type(exc).__name__,'message':str(exc),'traceback':traceback.format_exc()}
    traceback.print_exc()
finally:
    out.write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report),flush=True)
sys.exit(0 if report['passed'] else 1)
