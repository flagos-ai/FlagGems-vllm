#!/bin/bash
set -Eeuo pipefail
cd /results
export PYTHONPATH=/compiler:/candidate/src:/candidate:/deps:/legacy-deps
export HOME=/results/home XDG_CACHE_HOME=/results/cache/xdg
export FLAGGEMS_CACHE_DIR=/results/cache/gems TRITON_CACHE_DIR=/results/cache/triton
mkdir -p "$HOME" "$XDG_CACHE_HOME" "$FLAGGEMS_CACHE_DIR" "$TRITON_CACHE_DIR"
python=/usr/bin/python3
"$python" /task/verify-source.py /candidate /task/manifest-megamoe.json >source-before.json
"$python" - <<'PY' >runtime.json
import hashlib,importlib,importlib.metadata,json,os,pathlib,torch,triton,vllm,flaggems_vllm
assert torch.__version__=='2.13.0+cu130' and triton.__version__=='3.6.0' and vllm.__version__=='0.32.0'
expected={'flag-gems':'5.4.0','flagtree':'0.7.0','flagcx':'0.14.1+cuda13.3'}
for name,version in expected.items():assert importlib.metadata.version(name)==version,(name,importlib.metadata.version(name))
for name in ['VLLM_FL_FLAGOS_WHITELIST','VLLM_FL_FLAGOS_BLACKLIST','VLLM_FL_OP_WHITELIST','VLLM_FL_OP_BLACKLIST','VLLM_FL_PREFER','GEMS_CONFIG','FLAGGEMS_CONFIG']:
 assert name not in os.environ,name
from flaggems_vllm.utils.triton_version_utils import has_triton_tle
assert has_triton_tle(3,6,0)
assert torch.cuda.device_count()==2
assert torch.cuda.can_device_access_peer(0,1) and torch.cuda.can_device_access_peer(1,0)
assert pathlib.Path(flaggems_vllm.__file__).resolve()==pathlib.Path('/candidate/src/flaggems_vllm/__init__.py')
mods={name:str(pathlib.Path(importlib.import_module(name).__file__).resolve()) for name in ['torch','triton','flagtree','flag_gems','flagcx','vllm','flaggems_vllm','flaggems_vllm.runtime.backend._nvidia.hopper.ops.megamoe']}
kernel=pathlib.Path('/compiler/triton/_C/libtriton.so');assert hashlib.sha256(kernel.read_bytes()).hexdigest()=='385c1089a702a71df0ce847bdac0e71234d411396ac1bbdfe5d74bbd6528f43f'
print(json.dumps({'torch':torch.__version__,'triton':triton.__version__,'vllm':vllm.__version__,'packages':expected,'TLE':has_triton_tle(3,6,0),'P2P':[torch.cuda.can_device_access_peer(0,1),torch.cuda.can_device_access_peer(1,0)],'origins':mods,'gpu':torch.cuda.get_device_name(0),'device_count':torch.cuda.device_count(),'native_reference':'installed vllm0.32','cache':{x:os.environ[x] for x in ['FLAGGEMS_CACHE_DIR','TRITON_CACHE_DIR','XDG_CACHE_HOME']}}))
PY
export CLANG=/clang-toolchain/clang
CLANG=$(bash /candidate/tools/setup-tle-clang.sh /results/clang-prefix /results/clang-cache)
export CLANG
"$CLANG" --version >clang-version.txt 2>&1
"$python" -m pytest /candidate/tests/test_megamoe.py -q -rA -c /candidate/pytest.ini -o cache_dir=/results/cache/pytest --junitxml=/results/functional.xml >functional.log 2>&1
"$python" /task/verify-source.py /candidate /task/manifest-megamoe.json >source-after.json
