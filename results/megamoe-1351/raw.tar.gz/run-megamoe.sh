#!/bin/bash
set -Eeuo pipefail
cd /data/codex/fgv-revalidation-20261127/nvidia-megamoe-linux-v2
sha256sum -c SHA256SUMS >package-check-megamoe.log
sha256sum -c SHA256SUMS-megamoe >>package-check-megamoe.log
[[ -f prepared.json && ! -e results/megamoe ]]
exec 9>/tmp/codex-h20-gpu5.lock
flock -n 9
exec 8>/tmp/codex-h20-gpu6.lock
flock -n 8
mkdir -p results/megamoe
nvidia-smi --query-gpu=index,uuid,memory.used,utilization.gpu --format=csv,noheader,nounits >results/megamoe/gpu-before.csv
awk -F, '$1+0==5||$1+0==6{found++;gsub(/ /,"",$2);expected=($1+0==5?"GPU-09e798f6-daed-4a79-839f-6b1b610d5ada":"GPU-48d06395-bc23-9c46-9bff-a17af3cc7705");if($2!=expected||$3+0>16||$4+0!=0)exit 1} END{if(found!=2)exit 1}' results/megamoe/gpu-before.csv
uuid='GPU-09e798f6-daed-4a79-839f-6b1b610d5ada|GPU-48d06395-bc23-9c46-9bff-a17af3cc7705'
nvidia-smi --query-compute-apps=gpu_uuid,pid,used_memory --format=csv,noheader >results/megamoe/pids-before.csv
if grep -E "$uuid" results/megamoe/pids-before.csv; then exit 1; fi
image=sha256:bd8a5d7a8774800c92d714c0c226b32c1863f929150f36efd610aebcd12a335d
[[ "$(docker image inspect "$image" --format '{{.Id}}')" == "$image" ]]
name=fgv-revalidate-1351-20261127-v2
label=fgv-revalidation-20261127-nvidia-megamoe-v2
cid=$(docker create --pull=never --name "$name" --label "codex.task=$label" --gpus '"device=5,6"' --network host --ipc host --ulimit memlock=-1 --ulimit stack=67108864 \
 -v "$PWD:/task:ro" -v "$PWD/sources/megamoe:/candidate:ro" -v /data/codex/fgv-revalidation-20261127/nvidia/deps:/deps:ro \
 -v /tmp/codex-flaggems-kda-1249-8d2bcdf/deps:/legacy-deps:ro \
 -v /data/codex/flaggems-vllm-h20-marlin-0d86ec1/source/.venv/lib/python3.12/site-packages/triton:/compiler/triton:ro \
 -v /data/codex/flaggems-vllm-h20-marlin-0d86ec1/source/.venv/lib/python3.12/site-packages/flagtree:/compiler/flagtree:ro \
 -v /data/codex/flaggems-vllm-h20-marlin-0d86ec1/source/.venv/lib/python3.12/site-packages/flagtree-0.7.0.dist-info:/compiler/flagtree-0.7.0.dist-info:ro \
 -v /data/codex/flaggems-vllm-pr1249-marlin-20261117/toolchain-22:/clang-toolchain:ro \
 -v "$PWD/results/megamoe:/results" -e FLAGGEMS_VENDOR=nvidia -e TORCH_DEVICE_BACKEND_AUTOLOAD=0 -e PYTHONDONTWRITEBYTECODE=1 \
 --entrypoint bash "$image" /task/inside-megamoe.sh)
[[ "$cid" =~ ^[a-f0-9]{64}$ ]]
printf '%s\n' "$cid" >results/megamoe/cid
owned(){ [[ "$(docker inspect "$cid" --format '{{index .Config.Labels "codex.task"}}')" == "$label" ]]; }
cleanup(){
 if owned; then
  if [[ "$(docker inspect "$cid" --format '{{.State.Running}}')" == true ]]; then docker stop --time 60 "$cid" >results/megamoe/forced-stop.txt; fi
  docker inspect "$cid" --format '{{json .State}}' >results/megamoe/final-state.json
  docker rm "$cid" >results/megamoe/removed.txt
 fi
}
trap cleanup EXIT
set +e
timeout --signal=TERM --kill-after=65s 24m docker start -a "$cid" >results/megamoe/container.log 2>&1
status=$?
set -e
printf '%s\n' "$status" >results/megamoe/attach.exit
owned
docker inspect "$cid" --format '{{json .State}}' >results/megamoe/state-before-cleanup.json
cleanup
trap - EXIT
docker ps -a --no-trunc --format '{{.ID}}' >results/megamoe/all-container-ids-after.txt
if grep -Fx "$cid" results/megamoe/all-container-ids-after.txt; then exit 1; fi
nvidia-smi --query-gpu=index,uuid,memory.used,utilization.gpu --format=csv,noheader,nounits >results/megamoe/gpu-after.csv
nvidia-smi --query-compute-apps=gpu_uuid,pid,used_memory --format=csv,noheader >results/megamoe/pids-after.csv
awk -F, '$1+0==5||$1+0==6{found++;gsub(/ /,"",$2);expected=($1+0==5?"GPU-09e798f6-daed-4a79-839f-6b1b610d5ada":"GPU-48d06395-bc23-9c46-9bff-a17af3cc7705");if($2!=expected||$3+0>16||$4+0!=0)exit 1} END{if(found!=2)exit 1}' results/megamoe/gpu-after.csv
if grep -E "$uuid" results/megamoe/pids-after.csv; then exit 1; fi
printf '%s\n' "$status" >results/megamoe/exit
exit "$status"
